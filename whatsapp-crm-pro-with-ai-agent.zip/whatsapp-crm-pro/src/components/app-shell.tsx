"use client";
import {useEffect,useState} from "react";
import {usePathname,useRouter} from "next/navigation";
import Link from "next/link";
import {browserSupabase} from "@/lib/supabase/browser";
import {api} from "@/lib/fetcher";
import {Badge,Spinner} from "@/components/ui";
import {Activity,ArrowRight,BookOpen,ChevronDown,Contact,LayoutDashboard,LogOut,MessageCircleMore,RadioTower,Settings2,ShieldCheck,Sparkles,Zap} from "lucide-react";
const navigation=[
 {href:"/dashboard",name:"Overview",Icon:LayoutDashboard},
 {href:"/inbox",name:"Inbox",Icon:MessageCircleMore},
 {href:"/contacts",name:"Contacts",Icon:Contact},
 {href:"/campaigns",name:"Campaigns",Icon:RadioTower},
 {href:"/automations",name:"Automations",Icon:Zap},
 {href:"/agents",name:"AI Agents",Icon:Sparkles},
 {href:"/settings",name:"Settings",Icon:Settings2}
];
export function AppShell({children}:{children:React.ReactNode}){
 const pathname=usePathname(),router=useRouter();
 const [ready,setReady]=useState(false),[email,setEmail]=useState("");
 const [error,setError]=useState("");
 useEffect(()=>{
  let live=true;
  const boot=async()=>{
   try{
    const {data:{user}}=await browserSupabase().auth.getUser();
    if(!user){router.replace("/login");return;}
    if(!live)return;
    setEmail(user.email||"Account");
    await api("/api/bootstrap",{method:"POST"});
    if(live)setReady(true);
   }catch(e){if(live)setError(e instanceof Error?e.message:"Initialization failed");}
  };
  void boot();return()=>{live=false;};
 },[router]);
 if(error)return <div className="init-screen"><div className="init-error"><ShieldCheck size={30}/><h2>Setup needs attention</h2><p>{error}</p><p className="muted">Check .env.local, database schema, and CRM_OWNER_USER_ID, then refresh.</p><button onClick={()=>void browserSupabase().auth.signOut().then(()=>router.push("/login"))} className="btn btn-outline">Sign out</button></div></div>;
 if(!ready)return <div className="init-screen"><div className="brand-mark"><MessageCircleMore size={25}/></div><Spinner label="Preparing your workspace..."/></div>;
 const logout=async()=>{await browserSupabase().auth.signOut();router.push("/login");router.refresh();};
 return <div className="app-shell">
  <aside className="sidebar">
   <Link href="/dashboard" className="brand"><span className="brand-mark"><MessageCircleMore size={23}/></span><span className="brand-words"><b>pulse<span>.</span></b><small>WHATSAPP CRM</small></span></Link>
   <div className="sidebar-label">YOUR WORKSPACE</div>
   <nav className="side-nav">{navigation.map(({href,name,Icon})=><Link key={href} href={href} className={`nav-item ${pathname.startsWith(href)?"active":""}`}><Icon size={18}/><span>{name}</span>{pathname.startsWith(href)&&<span className="nav-dot"/>}</Link>)}</nav>
   <div className="sidebar-bottom"><div className="tip-card"><Sparkles size={19}/><strong>Make every conversation count.</strong><p>Respond faster. Build better customer relationships.</p><Link href="/automations">Explore automations <ArrowRight size={14}/></Link></div>
    <button onClick={logout} className="account-card"><span className="avatar">{email.slice(0,1).toUpperCase()}</span><span className="account-copy"><b>Workspace owner</b><small title={email}>{email}</small></span><LogOut size={17}/></button>
   </div>
  </aside>
  <div className="main-area"><header className="topbar"><div className="topbar-left"><span className="topbar-path">Workspace <ChevronDown size={14}/></span><span className="slash">/</span><strong>{navigation.find(n=>pathname.startsWith(n.href))?.name||"Overview"}</strong></div><div className="topbar-right"><span className="topbar-label"><Activity size={15}/> Connected to workspace</span><Badge tone="green"><span className="online-dot"/> Secure</Badge></div></header><main className="page-content">{children}</main><footer className="footer"><span>Pulse CRM • Built for the WhatsApp Business Platform</span><a href="https://developers.facebook.com/docs/whatsapp" target="_blank" rel="noreferrer"><BookOpen size={13}/> Meta API Docs</a></footer></div>
  <nav className="mobile-nav">{navigation.slice(1,6).map(({href,name,Icon})=><Link key={href} href={href} className={pathname.startsWith(href)?"selected":""}><Icon size={19}/><span>{name.split(" ")[0]}</span></Link>)}<Link href="/settings" className={pathname.startsWith("/settings")?"selected":""}><Settings2 size={19}/><span>Settings</span></Link></nav>
 </div>;
}
