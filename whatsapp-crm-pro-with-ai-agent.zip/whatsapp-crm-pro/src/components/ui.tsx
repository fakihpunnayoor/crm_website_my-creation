"use client";
import type {ButtonHTMLAttributes,InputHTMLAttributes,ReactNode} from "react";
import {AlertCircle,CheckCircle2,Inbox,LoaderCircle,X} from "lucide-react";
export function Button({children,variant="primary",className="",...props}:ButtonHTMLAttributes<HTMLButtonElement>&{variant?:"primary"|"subtle"|"danger"|"outline"}){
 return <button className={`btn btn-${variant} ${className}`} {...props}>{children}</button>;
}
export function PageHead({title,description,actions}:{title:string;description:string;actions?:ReactNode}){
 return <div className="page-head"><div><p className="eyebrow">WORKSPACE / {title.toUpperCase()}</p><h1>{title}</h1><p className="muted">{description}</p></div><div className="head-actions">{actions}</div></div>;
}
export function Badge({children,tone="neutral"}:{children:ReactNode;tone?:"neutral"|"green"|"amber"|"red"|"blue"}){
 return <span className={`badge badge-${tone}`}>{children}</span>;
}
export function Empty({title="Nothing here yet",description,icon}:{title?:string;description?:string;icon?:ReactNode}){
 return <div className="empty"><div className="empty-icon">{icon||<Inbox size={24}/>}</div><strong>{title}</strong>{description&&<p>{description}</p>}</div>;
}
export function Spinner({label="Loading..."}:{label?:string}){
 return <div className="loading"><LoaderCircle className="spin" size={20}/>{label}</div>;
}
export function Notice({message,onClose,good=false}:{message:string;onClose:()=>void;good?:boolean}){
 return <div role="status" className={`notice ${good?"notice-ok":"notice-error"}`}>{good?<CheckCircle2 size={18}/>:<AlertCircle size={18}/>}<span>{message}</span><button aria-label="Close" onClick={onClose}><X size={15}/></button></div>;
}
export function Input({label,...props}:InputHTMLAttributes<HTMLInputElement>&{label:string}){
 return <label className="field"><span>{label}</span><input {...props}/></label>;
}
export function Panel({children,className=""}:{children:ReactNode;className?:string}){
 return <section className={`panel ${className}`}>{children}</section>;
}
