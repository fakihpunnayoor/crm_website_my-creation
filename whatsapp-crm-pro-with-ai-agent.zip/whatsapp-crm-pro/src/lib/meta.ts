import { createHmac, timingSafeEqual } from "node:crypto";
export function verifyMetaSignature(raw:string,signature:string|null,secret:string):boolean {
  if(!signature?.startsWith("sha256=")||!secret) return false;
  const actual=signature.slice(7);
  if(!/^[a-fA-F0-9]{64}$/.test(actual)) return false;
  const expected=createHmac("sha256",secret).update(raw,"utf8").digest("hex");
  return timingSafeEqual(Buffer.from(actual,"hex"),Buffer.from(expected,"hex"));
}
function cfg(){
  const token=process.env.META_ACCESS_TOKEN;
  const id=process.env.META_PHONE_NUMBER_ID;
  if(!token||!id) throw new Error("META_ACCESS_TOKEN or META_PHONE_NUMBER_ID missing");
  const version=process.env.META_GRAPH_VERSION||"v27.0";
  if(!/^v\d+\.\d+$/.test(version)) throw new Error("META_GRAPH_VERSION invalid");
  return {token,id,version};
}
async function requestMeta(path:string,init:RequestInit={}) {
  const {token,version}=cfg();
  const response=await fetch(`https://graph.facebook.com/${version}/${path}`,{
    ...init,cache:"no-store",
    headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json",...init.headers}
  });
  const payload=await response.json().catch(()=>({}));
  if(!response.ok) {
    const m=payload?.error?.message||`Meta API HTTP ${response.status}`;
    throw new Error(`Meta: ${m}`);
  }
  return payload;
}
export async function sendText(to:string,body:string) {
  const {id}=cfg();
  return requestMeta(`${id}/messages`,{method:"POST",body:JSON.stringify({
    messaging_product:"whatsapp",to,type:"text",text:{preview_url:false,body}
  })});
}
export async function sendTemplate(to:string,name:string,language:string) {
  const {id}=cfg();
  return requestMeta(`${id}/messages`,{method:"POST",body:JSON.stringify({
    messaging_product:"whatsapp",to,type:"template",
    template:{name,language:{code:language}}
  })});
}
export async function checkMeta() {
  const {id}=cfg();
  return requestMeta(`${id}?fields=display_phone_number,verified_name,quality_rating`);
}
export async function checkSubscription() {
  const waba=process.env.META_WABA_ID;
  if(!waba) throw new Error("META_WABA_ID missing");
  return requestMeta(`${waba}/subscribed_apps`);
}
