import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

/** Refresh cookie-based Supabase sessions for SSR and API requests.
 * Follow the official @supabase/ssr Next.js 16 Proxy pattern: mirror any
 * refreshed cookies onto both the request and response.
 */
export async function updateSession(request:NextRequest) {
  let response=NextResponse.next({request});
  const supabase=createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {cookies:{
      getAll(){return request.cookies.getAll();},
      setAll(toSet,headers){
        for(const {name,value} of toSet)request.cookies.set(name,value);
        response=NextResponse.next({request});
        for(const {name,value,options} of toSet)response.cookies.set(name,value,options);
        for(const [name,value] of Object.entries(headers||{}))response.headers.set(name,value);
      }
    }}
  );
  // Do not rely on getSession() for server-side identity verification.
  await supabase.auth.getClaims();
  return response;
}
