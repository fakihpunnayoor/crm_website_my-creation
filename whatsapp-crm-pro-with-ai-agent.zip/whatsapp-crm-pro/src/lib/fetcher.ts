export async function api<T>(path:string, init?:RequestInit):Promise<T> {
  const response=await fetch(path,{cache:"no-store",...init,
    headers:{...(init?.body?{"Content-Type":"application/json"}:{}),...init?.headers}
  });
  const result=await response.json().catch(()=>({error:`HTTP ${response.status}`}));
  if(!response.ok)throw new Error(result.error||`Request failed (${response.status})`);
  return result as T;
}
export const post=<T=unknown>(path:string,body:unknown):Promise<T>=>api<T>(path,{method:"POST",body:JSON.stringify(body)});
export const patch=(path:string,body:unknown)=>api(path,{method:"PATCH",body:JSON.stringify(body)});
export const del=(path:string,body:unknown)=>api(path,{method:"DELETE",body:JSON.stringify(body)});
