import { NextResponse } from "next/server";
import { serverSupabase } from "@/lib/supabase/server";
export function jsonError(error:string, status=400) {
  return NextResponse.json({ error }, {status,headers:{"Cache-Control":"no-store"}});
}
export async function context() {
  const db = await serverSupabase();
  const {data:{user},error}=await db.auth.getUser();
  if(error||!user) return {error:jsonError("Sign in to continue",401)} as const;
  if(!process.env.CRM_OWNER_USER_ID||process.env.CRM_OWNER_USER_ID!==user.id)
    return {error:jsonError("Account is not authorized for this CRM deployment",403)} as const;
  const {data:workspace,error:workspaceErr}=await db.from("workspaces").select("id,name").eq("owner_id",user.id).maybeSingle();
  if(workspaceErr) return {error:jsonError("Database unavailable. Apply sql/schema.sql first.",500)} as const;
  if(!workspace) return {error:jsonError("Workspace missing. POST /api/bootstrap first.",409)} as const;
  return {db,user,workspace} as const;
}
export function apiFailure(error:unknown) {
  console.error("CRM API failure:",error);
  return jsonError("Server request failed; inspect server logs",500);
}
export async function jsonBody(req:Request) {
  try {return await req.json() as Record<string,unknown>;} catch {return null;}
}
export function validPhone(v:string) {
  const phone=v.replace(/[\s()-]/g,"").replace(/^\+/,"");
  return /^[1-9]\d{7,14}$/.test(phone)?phone:null;
}
