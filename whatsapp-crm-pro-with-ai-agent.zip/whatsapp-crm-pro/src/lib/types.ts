export type Contact = {
  id:string; workspace_id:string; phone_e164:string; name:string;
  opted_in:boolean; opted_in_at:string|null; blocked:boolean;
  tags:string[]; created_at:string;
};
export type Conversation = {
  id:string; workspace_id:string; contact_id:string; unread_count:number;
  last_message_at:string|null; last_preview:string|null; status:string;
  ai_paused?:boolean; ai_reply_count?:number; ai_handoff_summary?:string|null;
  contacts:Pick<Contact,"id"|"phone_e164"|"name">|null;
};
export type Message = {
  id:string; workspace_id:string; conversation_id:string; contact_id:string;
  direction:"inbound"|"outbound"; kind:string; body:string;
  status:string; external_id:string|null; created_at:string;
  error_text:string|null;
};
export type Campaign = {
  id:string; name:string; template_name:string; template_language:string;
  status:string; created_at:string;
};
export type AutomationRule = {
  id:string; name:string; keyword:string; reply_text:string;
  enabled:boolean; cooldown_minutes:number;
};
