export const fmtDate=(date:string|null|undefined)=>date?new Date(date).toLocaleString("en-IN",{dateStyle:"short",timeStyle:"short"}):"—";
export const fmtTime=(date:string|null|undefined)=>date?new Date(date).toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"}):"";
