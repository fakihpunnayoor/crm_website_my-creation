import { AiError, type ProviderResult } from '../types'
import { MAX_OUTPUT_TOKENS } from '../defaults'
import { mergeConsecutive, normalizeUsage, providerHttpError, toNetworkError, type ProviderArgs } from './shared'

/** Only an operator-controlled AI_BASE_URL from server env is permitted. */
export function normalizeOpenAiCompatibleBaseUrl(raw: string): string {
  let parsed: URL
  try { parsed = new URL(raw) } catch { throw new AiError('Set a valid AI_BASE_URL', { status: 400 }) }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.search || parsed.hash) {
    throw new AiError('AI_BASE_URL must be an HTTPS URL without credentials or query parameters', { status: 400 })
  }
  if (['localhost','127.0.0.1','0.0.0.0','::1'].includes(parsed.hostname) || parsed.hostname.endsWith('.local')) {
    throw new AiError('Private AI_BASE_URL hosts are blocked', { status: 400 })
  }
  const trimmed = parsed.toString().replace(/\/+$/, '')
  return trimmed.endsWith('/chat/completions') ? trimmed : `${trimmed}/chat/completions`
}
export async function generateOpenAiCompatible(args: ProviderArgs): Promise<ProviderResult> {
  const endpoint = normalizeOpenAiCompatibleBaseUrl(args.baseUrl ?? '')
  let response: Response
  try {
    response = await fetch(endpoint, {method:'POST',redirect:'error',headers:{
      Authorization:`Bearer ${args.apiKey}`, 'Content-Type':'application/json'
    },body:JSON.stringify({model:args.model,messages:[
      {role:'system',content:args.systemPrompt},...mergeConsecutive(args.messages)
    ],max_tokens:MAX_OUTPUT_TOKENS}),signal:AbortSignal.timeout(args.timeoutMs)})
  } catch(err) { throw toNetworkError(err) }
  if (!response.ok) throw await providerHttpError('OpenAI-compatible',response)
  const data = await response.json().catch(()=>null) as {
    choices?: {message?:{content?:string}}[];usage?:{prompt_tokens?:number;completion_tokens?:number;total_tokens?:number}
  } | null
  const value = data?.choices?.[0]?.message?.content
  if (!value?.trim()) throw new AiError('AI provider returned no reply')
  return {text:value,usage:normalizeUsage({prompt:data?.usage?.prompt_tokens,completion:data?.usage?.completion_tokens,total:data?.usage?.total_tokens})}
}
