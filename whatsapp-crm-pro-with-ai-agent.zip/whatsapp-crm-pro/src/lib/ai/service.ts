import type { SupabaseClient } from '@supabase/supabase-js'
import type { AiConfig, ChatMessage, AiUsage } from './types'
import { aiContextMessageLimit, buildSystemPrompt } from './defaults'
import { chunkText } from './chunk'
import { generateReply } from './generate'
import { latestUserMessage } from './query'
import { sendText } from '@/lib/meta'
import { adminSupabase } from '@/lib/supabase/server'

/** Adapted from the uploaded WACRM AI modules to Pulse's workspace, direction, kind and body schema. */
export async function loadAiConfig(db: SupabaseClient, workspaceId: string, preview = false): Promise<AiConfig | null> {
  const {data,error} = await db.from('ai_configs').select('provider,model,system_prompt,is_active,auto_reply_enabled,auto_reply_max_per_conversation').eq('workspace_id',workspaceId).maybeSingle()
  if(error) throw error
  if(!data || (!preview && !data.is_active)) return null
  const apiKey=process.env.AI_API_KEY?.trim()
  if(!apiKey) return null
  return {
    provider: data.provider, model: data.model, baseUrl: process.env.AI_BASE_URL?.trim() || null, apiKey,
    systemPrompt:data.system_prompt, isActive:data.is_active, autoReplyEnabled:data.auto_reply_enabled,
    autoReplyMaxPerConversation:data.auto_reply_max_per_conversation, handoffAgentId:null, embeddingsApiKey:null
  } as AiConfig
}

export async function buildContext(db:SupabaseClient, workspaceId:string, conversationId:string):Promise<ChatMessage[]> {
  const limit = Math.max(1, Math.min(30, aiContextMessageLimit()))
  const {data,error}=await db.from('messages').select('direction,kind,body').eq('workspace_id',workspaceId)
    .eq('conversation_id',conversationId).eq('kind','text').order('created_at',{ascending:false}).limit(limit)
  if(error) throw error
  return (data||[]).reverse().filter(x=>String(x.body||'').trim()).map(x=>({
    role:x.direction==='inbound'?'user':'assistant', content:String(x.body).trim()
  }))
}

/** Simple lexical retrieval derived from source knowledge chunking. No embeddings or vector schema required. */
export async function retrieveKnowledge(db:SupabaseClient,workspaceId:string,query:string,limit=4):Promise<string[]> {
  const {data,error}=await db.from('ai_knowledge_documents').select('title,content').eq('workspace_id',workspaceId).limit(40)
  if(error) throw error
  const tokens=Array.from(new Set(query.toLocaleLowerCase().split(/[\s,?!.:;()\[\]{}]+/u).filter(s=>s.length>=3))).slice(0,15)
  const options=(data||[]).flatMap(doc=>chunkText(String(doc.content),{maxChars:1100})
      .map(part=>({body:`${doc.title}\n${part}`,text:part.toLocaleLowerCase()})))
  return options.map(x=>({body:x.body,score:tokens.reduce((score,t)=>score+(x.text.includes(t)?1:0),0)}))
    .filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,limit).map(x=>x.body)
}
export async function generateForWorkspace(db:SupabaseClient,workspaceId:string,messages:ChatMessage[],mode:'auto_reply'|'draft'|'playground') {
  const config=await loadAiConfig(db,workspaceId,mode!=='auto_reply')
  if(!config) throw new Error('AI not configured: set AI_API_KEY and save agent settings')
  if(!messages.some(m=>m.role==='user')) throw new Error('Customer question required')
  const knowledge=await retrieveKnowledge(db,workspaceId,latestUserMessage(messages))
  const result=await generateReply({config,systemPrompt:buildSystemPrompt({userPrompt:config.systemPrompt,mode:mode==='auto_reply'?'auto_reply':'draft',knowledge}),messages})
  const text=result.text.slice(0,3800)
  return {text,handoff:result.handoff,usage:result.usage,config}
}
export async function recordUsage(db:SupabaseClient,workspaceId:string,mode:'auto_reply'|'draft'|'playground',config:AiConfig,usage:AiUsage|null,conversationId:string|null=null) {
  // Usage writes require service-role permissions; owner RLS grants read-only access to logs.
  const {error}=await adminSupabase().from('ai_usage_log').insert({workspace_id:workspaceId,conversation_id:conversationId,mode,
    provider:config.provider,model:config.model,prompt_tokens:usage?.promptTokens||0,completion_tokens:usage?.completionTokens||0})
  if(error) console.warn('AI usage logging failed:',error.message)
}

export interface InboundAiInput {
  workspaceId:string;conversationId:string;contactId:string;inboundRowId:string;recipientPhone:string
}
/** Called only after a new, verified inbound text was committed to the DB.
 * Failure is isolated from Meta's webhook acknowledgement. Keyword automations win over AI.
 */
export async function dispatchInboundToAi(input:InboundAiInput):Promise<void> {
  try {
    const db=adminSupabase()
    const config=await loadAiConfig(db,input.workspaceId)
    if(!config?.autoReplyEnabled) return
    const {data:conv,error:convErr}=await db.from('conversations').select('ai_paused,ai_reply_count').eq('id',input.conversationId)
      .eq('workspace_id',input.workspaceId).maybeSingle()
    if(convErr || !conv || conv.ai_paused || conv.ai_reply_count>=config.autoReplyMaxPerConversation)return
    const messages=await buildContext(db,input.workspaceId,input.conversationId)
    if(!messages.length || messages[messages.length-1]?.role!=='user') return
    // Never respond to an earlier customer message after a newer inbound arrives.
    const {data:latest}=await db.from('messages').select('id').eq('workspace_id',input.workspaceId)
      .eq('conversation_id',input.conversationId).eq('direction','inbound').order('created_at',{ascending:false}).limit(1).maybeSingle()
    if(latest?.id!==input.inboundRowId)return
    const {text,handoff,usage}=await generateForWorkspace(db,input.workspaceId,messages,'auto_reply')
    await recordUsage(db,input.workspaceId,'auto_reply',config,usage,input.conversationId)
    const {data:newest}=await db.from('messages').select('id').eq('workspace_id',input.workspaceId)
      .eq('conversation_id',input.conversationId).eq('direction','inbound').order('created_at',{ascending:false}).limit(1).maybeSingle()
    if(newest?.id!==input.inboundRowId)return
    if(handoff || !text.trim()) {
      const question=messages.filter(m=>m.role==='user').at(-1)?.content.slice(0,160)||''
      await db.from('conversations').update({ai_paused:true,ai_handoff_summary:`AI requested human help: ${question}`})
        .eq('workspace_id',input.workspaceId).eq('id',input.conversationId)
      return
    }
    const {data:claimed,error:claimError}=await db.rpc('claim_ai_reply_slot',{
      inbound_id:input.inboundRowId,max_replies:config.autoReplyMaxPerConversation
    })
    if(claimError){console.error('AI reply slot claim failed:',claimError.message);return}
    if(claimed!==true)return
    try {
      const {data:stillOn}=await db.from('conversations').select('ai_paused').eq('id',input.conversationId).maybeSingle()
      if(stillOn?.ai_paused){await db.from('ai_reply_attempts').update({result:'skipped'}).eq('inbound_message_id',input.inboundRowId);return}
      const result=await sendText(input.recipientPhone,text)
      const externalId=String(result?.messages?.[0]?.id||'')||null
      const {error:saveErr}=await db.from('messages').insert({workspace_id:input.workspaceId,
        conversation_id:input.conversationId,contact_id:input.contactId,external_id:externalId,
        direction:'outbound',kind:'text',body:text,status:'accepted'})
      if(saveErr) console.error('AI sent message but storing outbound failed:',saveErr.message)
      await db.from('conversations').update({last_preview:text.slice(0,500),last_message_at:new Date().toISOString()})
        .eq('workspace_id',input.workspaceId).eq('id',input.conversationId)
      await db.from('ai_reply_attempts').update({result:'sent'}).eq('inbound_message_id',input.inboundRowId)
    }catch(err){
      const msg=err instanceof Error?err.message:'AI WhatsApp send failed'
      console.error('AI auto-reply send failed:',msg)
      await db.from('ai_reply_attempts').update({result:'failed',error_text:msg.slice(0,300)})
        .eq('inbound_message_id',input.inboundRowId)
    }
  }catch(err){console.error('AI auto-reply failed:',err instanceof Error?err.message:'unknown error')}
}
