import {type NextRequest} from "next/server";
import {updateSession} from "@/lib/supabase/proxy";
export async function proxy(request:NextRequest){return updateSession(request);}
// Public Meta webhook + health endpoints must never depend on an interactive login.
export const config={matcher:["/((?!api/webhooks/whatsapp|api/health|_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"]};
