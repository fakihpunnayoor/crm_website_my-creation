"use client";
import {FormEvent,Suspense,useCallback,useEffect,useRef,useState} from "react";
import {useSearchParams} from "next/navigation";
import {api,post,patch} from "@/lib/fetcher";
import {Conversation,Message} from "@/lib/types";
import {fmtTime,fmtDate} from "@/lib/format";
import {Badge,Button,Empty,Notice,PageHead,Spinner} from "@/components/ui";
import {Bot,CheckCheck,Inbox,MessageCircleMore,Search,Send,ShieldCheck,Smile,UserRound} from "lucide-react";
function InboxClient(){
 const search=useSearchParams();
 const contactId=search.get("contactId");
 const [aiBusy,setAiBusy]=useState(false);
 const [items,setItems]=useState<Conversation[]>([]),[current,setCurrent]=useState<string|null>(null),[messages,setMessages]=useState<Message[]>([]),[loading,setLoading]=useState(true),[sendBusy,setSendBusy]=useState(false),[text,setText]=useState(""),[error,setError]=useState(""),[q,setQ]=useState("");
 const bottom=useRef<HTMLDivElement>(null);
 const loadConversations=useCallback(async()=>{try{const result=await api<{conversations:Conversation[]}>("/api/conversations");setItems(result.conversations);setCurrent(old=>{
  if(contactId){const target=result.conversations.find(c=>c.contact_id===contactId);if(target)return target.id;}
  return old&&result.conversations.some(c=>c.id===old)?old:(result.conversations[0]?.id||null);
 });}catch(e){setError(e instanceof Error?e.message:"Inbox unavailable");}finally{setLoading(false);}},[contactId]);
 const loadMessages=useCallback(async(id:string)=>{try{setMessages((await api<{messages:Message[]}>(`/api/messages?conversationId=${encodeURIComponent(id)}`)).messages);}catch(e){setError(e instanceof Error?e.message:"Messages unavailable");}},[]);
 useEffect(()=>{void loadConversations();const id=setInterval(()=>void loadConversations(),7000);return()=>clearInterval(id);},[loadConversations]);
 useEffect(()=>{if(!current){setMessages([]);return;}void loadMessages(current);void post("/api/conversations",{id:current}).catch(()=>{});const id=setInterval(()=>void loadMessages(current),5000);return()=>clearInterval(id);},[current,loadMessages]);
 useEffect(()=>{bottom.current?.scrollIntoView({behavior:"smooth",block:"end"});},[messages]);
 const send=async(e:FormEvent)=>{e.preventDefault();if(!current||!text.trim())return;setSendBusy(true);setError("");try{await post("/api/messages",{conversationId:current,text:text.trim()});setText("");await Promise.all([loadMessages(current),loadConversations()]);}catch(e){setError(e instanceof Error?e.message:"Send failed");}finally{setSendBusy(false);}};
 const toggleAi=async()=>{
  if(!current)return;const selected=items.find(c=>c.id===current);if(!selected)return;
  setAiBusy(true);setError('');try{
   await patch('/api/ai/conversation',{conversationId:current,paused:!selected.ai_paused});await loadConversations();
  }catch(e){setError(e instanceof Error?e.message:'Could not update AI handoff')}finally{setAiBusy(false)}
 };
 const draftAi=async()=>{
  if(!current)return;setAiBusy(true);setError('');try{
   const r=await post<{reply:string;handoff:boolean}>('/api/ai/draft',{conversationId:current});
   if(r.handoff&&!r.reply)setError('AI recommends human assistance instead of drafting a reply.');
   else setText(r.reply);
  }catch(e){setError(e instanceof Error?e.message:'AI draft failed')}finally{setAiBusy(false)}
 };
 const selected=items.find(c=>c.id===current);
 const filtered=items.filter(c=>`${c.contacts?.name||""} ${c.contacts?.phone_e164||""}`.toLowerCase().includes(q.toLowerCase()));
 return <><PageHead title="Inbox" description="One clean space for every customer conversation."/>{error&&<Notice message={error} onClose={()=>setError("")}/>}<div className="inbox-layout"><aside className="inbox-left"><div className="inbox-list-head"><div><h3>Messages</h3><Badge tone="blue">{items.length}</Badge></div><label className="search-wrap"><Search size={16}/><input placeholder="Search conversations" aria-label="Search conversations" value={q} onChange={e=>setQ(e.target.value)}/></label></div><div className="inbox-scroll">{loading?<Spinner/>:filtered.length===0?<Empty title="No conversations" description="Inbound WhatsApp messages will appear here."/>:filtered.map(c=><button key={c.id} className={`chat-list-item ${c.id===current?"selected":""}`} onClick={()=>setCurrent(c.id)}><span className="person-avatar">{(c.contacts?.name||"?").slice(0,1).toUpperCase()}</span><span className="chat-list-copy"><span className="chat-list-name">{c.contacts?.name||"Unknown"}<small>{fmtTime(c.last_message_at)}</small></span><span className="chat-list-preview">{c.last_preview||"Start a conversation"}</span></span>{c.unread_count>0&&<span className="unread-bubble">{c.unread_count}</span>}</button>)}</div></aside>
 <section className="chat-room">{!selected?<Empty title="Select a conversation" description="Choose a contact from the left to see their messages." icon={<Inbox size={25}/>} />:<><div className="chat-room-head"><span className="person-avatar large">{selected.contacts?.name?.slice(0,1).toUpperCase()||"?"}</span><div><strong>{selected.contacts?.name||"Unknown"}</strong><p>+{selected.contacts?.phone_e164}</p></div><div className="ai-inbox-actions"><Badge tone={selected.ai_paused?'amber':'green'}><Bot size={13}/>{selected.ai_paused?'AI paused':'AI ready'}</Badge><button disabled={aiBusy} title="Pause or resume automatic AI replies for this conversation" onClick={()=>void toggleAi()}>{selected.ai_paused?'Resume AI':'Pause AI'}</button></div></div><div className="chat-messages"><div className="chat-day">Conversation history</div>{messages.length===0?<div className="chat-zero"><MessageCircleMore size={28}/><p>No messages yet. Free-form replies require a recent customer message.</p></div>:messages.map(m=><div key={m.id} className={`message-row ${m.direction==="outbound"?"outgoing":"incoming"}`}><div className="message-bubble"><div className="message-text">{m.body}</div><div className="message-meta"><span>{fmtTime(m.created_at)}</span>{m.direction==="outbound"&&<CheckCheck size={13}/>}<small>{m.status}</small></div></div></div>)}<div ref={bottom}/></div><form className="chat-compose" onSubmit={send}><div className="composer-helper"><ShieldCheck size={14}/> Free-form replies work inside Meta's 24-hour customer service window. <button className="ai-draft-btn" disabled={aiBusy} type="button" onClick={()=>void draftAi()}><Bot size={14}/>{aiBusy?'Thinking...':'Draft with AI'}</button></div><div className="composer-row"><Smile size={18} className="muted-icon"/><input value={text} onChange={e=>setText(e.target.value)} placeholder="Write a message..." aria-label="Message text" maxLength={4096}/><Button type="submit" disabled={!text.trim()||sendBusy}>{sendBusy?"Sending":"Send"}<Send size={15}/></Button></div></form></>}</section>
 <aside className="chat-detail"><div className="detail-avatar"><UserRound size={28}/></div><h3>{selected?.contacts?.name||"Contact profile"}</h3><p>{selected?`+${selected.contacts?.phone_e164}`:"Select a chat to view details"}</p><div className="detail-divider"/><div className="detail-line"><span>Channel</span><Badge tone="green">WhatsApp</Badge></div><div className="detail-line"><span>Messages</span><b>{messages.length}</b></div><div className="detail-line"><span>AI replies</span><b>{selected?.ai_reply_count||0}</b></div>{selected?.ai_handoff_summary&&<p className="ai-handoff-note">{selected.ai_handoff_summary}</p>}<div className="detail-line"><span>Last activity</span><small>{fmtDate(selected?.last_message_at)}</small></div><div className="detail-help"><MessageCircleMore size={21}/><b>Always in sync</b><p>Message history is stored in your Supabase workspace.</p></div></aside></div></>;
}

export default function InboxPage(){
 return <Suspense fallback={<Spinner label="Loading inbox..."/>}><InboxClient/></Suspense>;
}
