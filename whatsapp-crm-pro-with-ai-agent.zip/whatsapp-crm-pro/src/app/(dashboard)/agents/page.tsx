'use client'
import {FormEvent,useCallback,useEffect,useState} from 'react'
import {api,del,post} from '@/lib/fetcher'
import {Badge,Button,Notice,PageHead,Panel,Spinner,Input} from '@/components/ui'
import {Bot,Sparkles,ShieldCheck,Send,BookOpen,Trash2,BarChart3,Settings2} from 'lucide-react'

type Tab='setup'|'playground'|'knowledge'|'usage'
type AiSettings={provider:'openai'|'anthropic'|'openai_compatible';model:string;system_prompt:string;is_active:boolean;auto_reply_enabled:boolean;auto_reply_max_per_conversation:number}
type Doc={id:string;title:string;content:string;created_at:string}
type Turn={role:'user'|'assistant';content:string;handoff?:boolean}
type Usage={mode:string;provider:string;model:string;prompt_tokens:number;completion_tokens:number;created_at:string}
export default function AgentsPage(){
 const [tab,setTab]=useState<Tab>('setup'),[configured,setConfigured]=useState(false),[hasKey,setHasKey]=useState(false)
 const [config,setConfig]=useState<AiSettings>({provider:'openai',model:'gpt-4o-mini',system_prompt:'',is_active:false,auto_reply_enabled:false,auto_reply_max_per_conversation:5})
 const [busy,setBusy]=useState(true),[saving,setSaving]=useState(false),[error,setError]=useState(''),[good,setGood]=useState('')
 const [docs,setDocs]=useState<Doc[]>([]),[title,setTitle]=useState(''),[content,setContent]=useState('')
 const [turns,setTurns]=useState<Turn[]>([]),[input,setInput]=useState(''),[sending,setSending]=useState(false)
 const [usage,setUsage]=useState<Usage[]>([])
 const load=useCallback(async()=>{
  try{
   const [a,k,u]=await Promise.all([
    api<{configured:boolean;hasKey:boolean;config:AiSettings}>('/api/ai/config'),
    api<{documents:Doc[]}>('/api/ai/knowledge'),
    api<{usage:Usage[]}>('/api/ai/usage')
   ])
   setConfig(a.config);setConfigured(a.configured);setHasKey(a.hasKey);setDocs(k.documents);setUsage(u.usage)
   if(a.configured)setTab('playground')
  }catch(e){setError(e instanceof Error?e.message:'AI add-on unavailable. Apply sql/ai-agent-migration.sql first.')}
  finally{setBusy(false)}
 },[])
 useEffect(()=>{void load()},[load])
 const save=async(e:FormEvent)=>{e.preventDefault();setSaving(true);setError('');try{
  await post('/api/ai/config',config);setConfigured(true);setGood('AI Agent configuration saved')
 }catch(e){setError(e instanceof Error?e.message:'Save failed')}finally{setSaving(false)}}
 const addDoc=async(e:FormEvent)=>{e.preventDefault();setSaving(true);setError('');try{
  const r=await post<{document:Doc}>('/api/ai/knowledge',{title,content});setDocs(d=>[r.document,...d]);setTitle('');setContent('');setGood('Knowledge document added')
 }catch(e){setError(e instanceof Error?e.message:'Knowledge save failed')}finally{setSaving(false)}}
 const removeDoc=async(id:string)=>{if(!confirm('Remove this knowledge document?'))return;try{
  await del('/api/ai/knowledge',{id});setDocs(d=>d.filter(x=>x.id!==id))
 }catch(e){setError(e instanceof Error?e.message:'Delete failed')}}
 const playground=async(e:FormEvent)=>{e.preventDefault();const q=input.trim();if(!q)return;setSending(true);setError('')
  const next:Turn[]=[...turns,{role:'user',content:q}];setTurns(next);setInput('')
  try{
   const result=await post<{reply:string;handoff:boolean}>('/api/ai/playground',{messages:next.map(({role,content})=>({role,content}))})
   setTurns([...next,{role:'assistant',content:result.reply||'(Human assistance required)',handoff:result.handoff}])
  }catch(e){setError(e instanceof Error?e.message:'AI request failed');setInput(q)}finally{setSending(false)}
 }
 const tabs:[Tab,string,typeof Bot][]=[['setup','Setup',Settings2],['playground','Playground',Bot],['knowledge','Knowledge',BookOpen],['usage','Usage',BarChart3]]
 return <><PageHead title="AI Agents" description="Automatic WhatsApp support, grounded in your business information."
 actions={<Badge tone={configured&&config.is_active?'green':'amber'}>{configured&&config.is_active?'AI Enabled':'AI Off / Setup'}</Badge>}/>
 {error&&<Notice message={error} onClose={()=>setError('')}/>} {good&&<Notice good message={good} onClose={()=>setGood('')}/>}
 <div className="ai-tabs" role="tablist">{tabs.map(([key,label,Icon])=><button key={key} role="tab" aria-selected={tab===key} className={tab===key?'active':''} onClick={()=>setTab(key)}><Icon size={16}/>{label}</button>)}</div>
 {busy?<Spinner label="Loading AI Agent..."/>:tab==='setup'?<div className="ai-columns"><Panel><div className="panel-head"><div><h3>AI Agent Setup</h3><p>Owner-controlled settings. Auto-reply is disabled until you enable it.</p></div><Sparkles size={23}/></div>
 <form className="ai-form" onSubmit={save}>
  <div className="ai-grid"><label className="field"><span>AI Provider</span><select value={config.provider} onChange={e=>setConfig(c=>({...c,provider:e.target.value as AiSettings['provider'],model:e.target.value==='anthropic'?'claude-haiku-4-5-20251001':e.target.value==='openai'?'gpt-4o-mini':'model-id'}))}><option value="openai">OpenAI</option><option value="anthropic">Anthropic</option><option value="openai_compatible">OpenAI-compatible API</option></select></label>
  <Input label="Model ID" value={config.model} maxLength={120} required onChange={e=>setConfig(c=>({...c,model:e.target.value}))}/></div>
  <label className="field"><span>Business system prompt</span><textarea rows={6} value={config.system_prompt} maxLength={12000} onChange={e=>setConfig(c=>({...c,system_prompt:e.target.value}))} placeholder="You are Efky Store's helpful sales assistant. Answer using the product details and store policies in the Knowledge tab. Never invent stock, prices, delivery dates or policies."/></label>
  <label className="ai-toggle"><input type="checkbox" checked={config.is_active} onChange={e=>setConfig(c=>({...c,is_active:e.target.checked,auto_reply_enabled:e.target.checked?c.auto_reply_enabled:false}))}/><span><strong>Enable AI Agent</strong><small>Allows Playground and manual AI drafts to work</small></span></label>
  <label className="ai-toggle"><input type="checkbox" checked={config.auto_reply_enabled} disabled={!config.is_active} onChange={e=>setConfig(c=>({...c,auto_reply_enabled:e.target.checked}))}/><span><strong>Automatically reply to WhatsApp</strong><small>Incoming text only. Keyword rules take priority. No marketing opt-in inferred.</small></span></label>
  <Input type="number" min={1} max={50} label="Maximum auto-replies per conversation" value={config.auto_reply_max_per_conversation} onChange={e=>setConfig(c=>({...c,auto_reply_max_per_conversation:Number(e.target.value)}))}/>
  <Button type="submit" disabled={saving}>{saving?'Saving...':'Save AI Agent Settings'}</Button>
 </form></Panel><Panel className="ai-sidebar-panel"><h3><ShieldCheck size={19}/> API Key & safety</h3><p>Your provider API key is stored in the <strong>server environment</strong> only; it cannot be viewed from the browser or CRM settings.</p><div className="ai-status">AI_API_KEY <Badge tone={hasKey?'green':'red'}>{hasKey?'Present':'Missing'}</Badge></div><p>Add <code>AI_API_KEY</code> and optionally <code>AI_BASE_URL</code> to your local <code>.env.local</code>, then restart <code>npm run dev</code>. Choose a provider and model above.</p><p>First test via Playground. Real automatic replies require a verified WhatsApp incoming webhook and a valid 24-hour conversation window.</p><p>AI can hand over to a human. Pause it per conversation inside Inbox.</p></Panel></div>
 :tab==='knowledge'?<div className="ai-columns"><Panel><div className="panel-head"><div><h3>Knowledge Base</h3><p>Add your real products, prices, FAQs, returns, shipping and store policies.</p></div><BookOpen size={20}/></div><form className="ai-form" onSubmit={addDoc}><Input label="Document title" maxLength={150} value={title} required onChange={e=>setTitle(e.target.value)} placeholder="Shipping and returns FAQ"/><label className="field"><span>Content (up to 20,000 characters)</span><textarea rows={9} required maxLength={20000} value={content} onChange={e=>setContent(e.target.value)} placeholder="Q: How long does delivery take?\nA: ..."/></label><Button type="submit" disabled={saving||!title.trim()||!content.trim()}>Add knowledge document</Button></form></Panel><Panel className="ai-sidebar-panel"><h3>Saved knowledge ({docs.length})</h3>{docs.length===0?<p>No documents yet. AI will avoid making up product facts, and may request human help.</p>:docs.map(d=><div className="ai-doc" key={d.id}><div><strong>{d.title}</strong><small>{d.content.slice(0,125)}{d.content.length>125?'…':''}</small></div><button title="Delete document" aria-label={`Delete ${d.title}`} onClick={()=>void removeDoc(d.id)}><Trash2 size={16}/></button></div>)}</Panel></div>
 :tab==='playground'?<div className="ai-columns"><Panel><div className="panel-head"><div><h3>Agent Playground</h3><p>Test answers before enabling automatic WhatsApp replies. This does NOT send real messages.</p></div><Bot size={21}/></div><div className="ai-transcript">{turns.length===0?<div className="ai-empty"><Sparkles size={27}/><strong>Try a customer question</strong><p>Ask about prices, availability, shipping or returns.</p></div>:turns.map((turn,i)=><div key={i} className={`ai-bubble ${turn.role}`}>{turn.content}{turn.handoff&&<small>Human handoff requested</small>}</div>)}{sending&&<Spinner label="Agent is thinking..."/>}</div><form className="ai-composer" onSubmit={playground}><input value={input} onChange={e=>setInput(e.target.value)} placeholder="Example: Do you have a black hoodie in XL?" maxLength={2000}/><Button type="submit" disabled={sending||!input.trim()}><Send size={16}/> Send</Button></form><div className="ai-form"><Button type="button" variant="outline" onClick={()=>setTurns([])} disabled={!turns.length||sending}>Reset conversation</Button></div></Panel><Panel className="ai-sidebar-panel"><h3>Safe testing</h3><p>Set up the provider key and save AI settings before using the Playground.</p><p>The bot replies in the customer's language, uses your business knowledge when relevant, and requests a human if it cannot confidently answer.</p><Button variant="outline" onClick={()=>setTab('setup')}>Go to Setup</Button></Panel></div>
 :<Panel><div className="panel-head"><div><h3>AI Usage</h3><p>Latest 100 model calls recorded for this workspace. Provider costs depend on usage.</p></div><BarChart3 size={21}/></div><div className="ai-metrics"><div><small>Calls shown</small><strong>{usage.length}</strong></div><div><small>Input tokens</small><strong>{usage.reduce((n,u)=>n+u.prompt_tokens,0).toLocaleString()}</strong></div><div><small>Output tokens</small><strong>{usage.reduce((n,u)=>n+u.completion_tokens,0).toLocaleString()}</strong></div></div><div className="ai-usage-list">{usage.length?usage.map((u,i)=><div key={i}><span><strong>{u.mode.replace('_',' ')}</strong> · {u.provider} / {u.model}</span><small>{u.prompt_tokens+u.completion_tokens} tokens · {new Date(u.created_at).toLocaleString()}</small></div>):<p className="muted">No AI usage yet.</p>}</div></Panel>}
 </>
}
