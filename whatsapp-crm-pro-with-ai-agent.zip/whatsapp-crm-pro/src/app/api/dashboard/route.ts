import {context,jsonError,apiFailure} from "@/lib/api";
import {NextResponse} from "next/server";
export async function GET(){
 try {
  const ctx=await context(); if("error" in ctx) return ctx.error;
  const {db,workspace}=ctx;
  const [contacts,conversations,messages,campaigns,recent]=await Promise.all([
    db.from("contacts").select("id",{count:"exact",head:true}).eq("workspace_id",workspace.id),
    db.from("conversations").select("id",{count:"exact",head:true}).eq("workspace_id",workspace.id).eq("status","open"),
    db.from("messages").select("id",{count:"exact",head:true}).eq("workspace_id",workspace.id),
    db.from("campaigns").select("id",{count:"exact",head:true}).eq("workspace_id",workspace.id),
    db.from("conversations").select("id,last_preview,last_message_at,unread_count,contacts(id,name,phone_e164)").eq("workspace_id",workspace.id).order("last_message_at",{ascending:false,nullsFirst:false}).limit(6)
  ]);
  const e=[contacts,conversations,messages,campaigns,recent].find(x=>x.error)?.error;
  if(e) return jsonError(e.message,500);
  return NextResponse.json({stats:{contacts:contacts.count||0,conversations:conversations.count||0,messages:messages.count||0,campaigns:campaigns.count||0},recent:recent.data||[]});
 }catch(e){return apiFailure(e);}
}
