import {NextRequest,NextResponse,after} from "next/server";
import {dispatchInboundToAi} from "@/lib/ai/service";
import {verifyMetaSignature,sendText} from "@/lib/meta";
import {adminSupabase} from "@/lib/supabase/server";
export const runtime="nodejs";
export const maxDuration=60;

// Meta GET verification challenge.
export async function GET(req:NextRequest){
 const q=req.nextUrl.searchParams;
 const token=process.env.META_WEBHOOK_VERIFY_TOKEN;
 if(token && q.get("hub.mode")==="subscribe" && q.get("hub.verify_token")===token){
  return new NextResponse(q.get("hub.challenge")||"",{status:200,headers:{"Content-Type":"text/plain"}});
 }
 return new NextResponse("Verification failed",{status:403});
}

type MetaMessage={id?:string;from?:string;timestamp?:string;type?:string;text?:{body?:string}};
type MetaStatus={id?:string;status?:string;errors?:{message?:string}[]};
type MetaValue={metadata?:{phone_number_id?:string};contacts?:{wa_id?:string;profile?:{name?:string}}[];messages?:MetaMessage[];statuses?:MetaStatus[]};

export async function POST(req:NextRequest){
 const secret=process.env.META_APP_SECRET||"";
 const length=Number(req.headers.get("content-length")||0);
 if(length>1024*1024)return NextResponse.json({error:"Payload too large"},{status:413});
 const raw=await req.text();
 if(raw.length>1024*1024)return NextResponse.json({error:"Payload too large"},{status:413});
 if(!verifyMetaSignature(raw,req.headers.get("x-hub-signature-256"),secret))
   return NextResponse.json({error:"Invalid Meta signature"},{status:403});
 let event:unknown;
 try{event=JSON.parse(raw);}catch{return NextResponse.json({error:"Invalid JSON"},{status:400});}
 if(!event||typeof event!=="object"||!("entry" in event))return NextResponse.json({ok:true});
 const entries=(event as {entry?:{changes?:{field?:string;value?:MetaValue}[]}[]}).entry;
 if(!Array.isArray(entries))return NextResponse.json({ok:true});
 try{
  const admin=adminSupabase();
  const owner=process.env.CRM_OWNER_USER_ID;
  if(!owner){console.error("Webhook: CRM_OWNER_USER_ID missing");return NextResponse.json({error:"Server unconfigured"},{status:503});}
  const {data:workspace,error:workspaceError}=await admin.from("workspaces").select("id").eq("owner_id",owner).maybeSingle();
  if(workspaceError||!workspace)return NextResponse.json({error:"Workspace missing"},{status:503});
  const expectedPhone=process.env.META_PHONE_NUMBER_ID;
  if(!expectedPhone)return NextResponse.json({error:"META_PHONE_NUMBER_ID missing"},{status:503});
  for(const entry of entries){
   for(const change of entry.changes||[]){
    if(change.field!=="messages")continue;
    const v=change.value;
    if(!v||String(v.metadata?.phone_number_id)!==expectedPhone)continue;
    for(const s of v.statuses||[]){
      if(!s.id||!s.status)continue;
      await admin.from("messages").update({status:s.status,error_text:s.errors?.[0]?.message||null}).eq("workspace_id",workspace.id).eq("external_id",s.id);
      // Campaign delivery receipts are distinct from Meta API acceptance.
      await admin.from("campaign_deliveries").update({status:s.status,error_text:s.errors?.[0]?.message||null}).eq("workspace_id",workspace.id).eq("external_id",s.id);
    }
    for(const m of v.messages||[]){
      if(!m.id||!m.from||!/^[1-9]\d{7,14}$/.test(m.from))continue;
      const {data:duplicate}=await admin.from("messages").select("id").eq("external_id",m.id).maybeSingle();
      if(duplicate)continue;
      const name=v.contacts?.find(c=>c.wa_id===m.from)?.profile?.name?.slice(0,100)||m.from;
      let {data:contact}=await admin.from("contacts").select("id,name,blocked").eq("workspace_id",workspace.id).eq("phone_e164",m.from).maybeSingle();
      if(!contact){
        const inserted=await admin.from("contacts").insert({workspace_id:workspace.id,phone_e164:m.from,name}).select("id,name,blocked").maybeSingle();
        contact=inserted.data;
        if(!contact) contact=(await admin.from("contacts").select("id,name,blocked").eq("workspace_id",workspace.id).eq("phone_e164",m.from).maybeSingle()).data;
      }
      if(!contact)throw new Error("Contact upsert failed");
      let {data:conv}=await admin.from("conversations").select("id,unread_count").eq("workspace_id",workspace.id).eq("contact_id",contact.id).maybeSingle();
      if(!conv){
        conv=(await admin.from("conversations").insert({workspace_id:workspace.id,contact_id:contact.id}).select("id,unread_count").maybeSingle()).data;
        if(!conv)conv=(await admin.from("conversations").select("id,unread_count").eq("workspace_id",workspace.id).eq("contact_id",contact.id).maybeSingle()).data;
      }
      if(!conv)throw new Error("Conversation upsert failed");
      const kind=m.type||"unknown";
      const text=kind==="text"?String(m.text?.body||""):`[${kind} message]`;
      const created=m.timestamp&&/^\d+$/.test(m.timestamp)?new Date(Number(m.timestamp)*1000).toISOString():new Date().toISOString();
      const {data:inboundRow,error:insertErr}=await admin.from("messages").insert({workspace_id:workspace.id,conversation_id:conv.id,contact_id:contact.id,external_id:m.id,direction:"inbound",kind,body:text,status:"received",created_at:created}).select("id").single();
      if(insertErr){if(insertErr.code==="23505")continue;throw new Error(insertErr.message);}
      if(!inboundRow)throw new Error("Inbound message id missing");
      await admin.from("conversations").update({last_preview:text.slice(0,500),last_message_at:created,unread_count:(conv.unread_count||0)+1,status:"open"}).eq("id",conv.id);
      // Keyword automations only run on newly persisted inbound text. Never mark as marketing opt-in.
      if(kind!=="text"||!text.trim()||contact.blocked)continue;
      // Honor explicit marketing opt-outs before running any keyword auto-replies.
      if(/^(stop|unsubscribe|opt[ -]?out)$/i.test(text.trim())){
        await admin.from("contacts").update({opted_in:false,opted_in_at:null}).eq("workspace_id",workspace.id).eq("id",contact.id);
        const confirmation="You have been unsubscribed from promotional WhatsApp messages.";
        try {
          const ack=await sendText(m.from,confirmation);
          const ackId=String(ack?.messages?.[0]?.id||"");
          await admin.from("messages").insert({workspace_id:workspace.id,conversation_id:conv.id,contact_id:contact.id,external_id:ackId||null,direction:"outbound",kind:"text",body:confirmation,status:"accepted"});
          await admin.from("conversations").update({last_preview:confirmation,last_message_at:new Date().toISOString()}).eq("id",conv.id);
        }catch(e){console.error("Opt-out acknowledgement failed:",e);}
        continue;
      }
      const {data:rules,error:rulesErr}=await admin.from("automation_rules").select("id,keyword,reply_text,cooldown_minutes").eq("workspace_id",workspace.id).eq("enabled",true).order("created_at",{ascending:true}).limit(50);
      if(rulesErr){console.error("Keyword rule lookup failed:",rulesErr.message);continue;}
      const rule=(rules||[]).find(r=>text.toLocaleLowerCase().includes(String(r.keyword).toLocaleLowerCase()));
      if(rule){
       // Existing deterministic automations take precedence. Never send both a rule and AI reply.
       const cutoff=new Date(Date.now()-rule.cooldown_minutes*60_000).toISOString();
       const {data:prior}=await admin.from("automation_runs").select("id").eq("workspace_id",workspace.id).eq("rule_id",rule.id).eq("contact_id",contact.id).gte("sent_at",cutoff).limit(1).maybeSingle();
       if(prior)continue;
       try{
        const result=await sendText(m.from,rule.reply_text);
        const outboundId=String(result?.messages?.[0]?.id||"");
        await admin.from("automation_runs").insert({workspace_id:workspace.id,rule_id:rule.id,contact_id:contact.id});
        await admin.from("messages").insert({workspace_id:workspace.id,conversation_id:conv.id,contact_id:contact.id,external_id:outboundId||null,direction:"outbound",kind:"text",body:rule.reply_text,status:"accepted"});
        await admin.from("conversations").update({last_preview:rule.reply_text,last_message_at:new Date().toISOString()}).eq("id",conv.id);
       }catch(e){console.error("Auto-reply failed:",e);}
       continue;
      }
      // Run after the HTTP response: Meta should not be blocked by LLM latency.
      after(async()=>{await dispatchInboundToAi({workspaceId:workspace.id,conversationId:conv.id,
        contactId:contact.id,inboundRowId:inboundRow.id,recipientPhone:m.from!});});
    }
   }
  }
  return NextResponse.json({ok:true});
 }catch(e){
  console.error("Webhook processing failed:",e);
  // Retry delivery on transient database failures; duplicate message IDs are deduplicated.
  return NextResponse.json({error:"Webhook processing failed"},{status:500});
 }
}
