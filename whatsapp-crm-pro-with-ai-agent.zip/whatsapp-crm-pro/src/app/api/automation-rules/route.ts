import {context,apiFailure,jsonError,jsonBody} from "@/lib/api";
import {NextResponse} from "next/server";
export async function GET(){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
 const {data,error}=await ctx.db.from("automation_rules").select("*").eq("workspace_id",ctx.workspace.id).order("created_at",{ascending:false});
 if(error)return jsonError(error.message,500);return NextResponse.json({rules:data});
 }catch(e){return apiFailure(e);}
}
export async function POST(req:Request){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
 const b=await jsonBody(req);if(!b)return jsonError("Invalid JSON");
 const name=String(b.name||"").trim().slice(0,80),keyword=String(b.keyword||"").trim().slice(0,100),reply=String(b.reply_text||"").trim().slice(0,2000);
 if(!name||!keyword||!reply)return jsonError("Rule name, keyword, reply are required");
 const {data,error}=await ctx.db.from("automation_rules").insert({workspace_id:ctx.workspace.id,name,keyword,reply_text:reply,enabled:true,cooldown_minutes:60}).select().single();
 if(error)return jsonError(error.message,500);return NextResponse.json({rule:data},{status:201});
 }catch(e){return apiFailure(e);}
}
export async function PATCH(req:Request){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
 const b=await jsonBody(req);if(!b||typeof b.id!=="string"||typeof b.enabled!=="boolean")return jsonError("id and enabled required");
 const {data,error}=await ctx.db.from("automation_rules").update({enabled:b.enabled}).eq("id",b.id).eq("workspace_id",ctx.workspace.id).select().maybeSingle();
 if(error)return jsonError(error.message,500);if(!data)return jsonError("Rule not found",404);return NextResponse.json({rule:data});
 }catch(e){return apiFailure(e);}
}
export async function DELETE(req:Request){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
 const b=await jsonBody(req);if(!b||typeof b.id!=="string")return jsonError("id required");
 const {error}=await ctx.db.from("automation_rules").delete().eq("id",b.id).eq("workspace_id",ctx.workspace.id);
 if(error)return jsonError(error.message,500);return NextResponse.json({ok:true});
 }catch(e){return apiFailure(e);}
}
