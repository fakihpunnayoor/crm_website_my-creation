import {NextResponse} from 'next/server'
import {context,jsonBody,jsonError,apiFailure} from '@/lib/api'
export async function PATCH(req:Request){
 try{const ctx=await context();if('error' in ctx)return ctx.error
  const b=await jsonBody(req)
  if(!b||typeof b.conversationId!=='string'||typeof b.paused!=='boolean')return jsonError('conversationId and paused required')
  const {data,error}=await ctx.db.from('conversations').update({ai_paused:b.paused,ai_handoff_summary:b.paused?'Paused by an operator':null})
    .eq('workspace_id',ctx.workspace.id).eq('id',b.conversationId).select('id,ai_paused,ai_reply_count,ai_handoff_summary').maybeSingle()
  if(error)return jsonError(error.message,500)
  if(!data)return jsonError('Conversation not found',404)
  return NextResponse.json({conversation:data})
 }catch(e){return apiFailure(e)}
}
