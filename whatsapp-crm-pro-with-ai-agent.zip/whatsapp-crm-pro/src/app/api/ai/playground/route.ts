import {NextResponse} from 'next/server'
import {context,jsonBody,jsonError} from '@/lib/api'
import {generateForWorkspace,recordUsage} from '@/lib/ai/service'
import type {ChatMessage} from '@/lib/ai/types'
export async function POST(req:Request){
 const ctx=await context();if('error' in ctx)return ctx.error
 const b=await jsonBody(req);if(!b||!Array.isArray(b.messages))return jsonError('messages array required')
 const messages:ChatMessage[]=b.messages.slice(-20).filter((x:unknown)=>{
   if(!x||typeof x!=='object')return false
   const y=x as Record<string,unknown>
   return (y.role==='user'||y.role==='assistant') && typeof y.content==='string' && y.content.length<=2000
 }).map((x:{role:'user'|'assistant';content:string})=>({role:x.role,content:x.content}))
 if(!messages.length || messages[messages.length-1].role!=='user')return jsonError('Last turn must be from customer')
 try {
  const result=await generateForWorkspace(ctx.db,ctx.workspace.id,messages,'playground')
  await recordUsage(ctx.db,ctx.workspace.id,'playground',result.config,result.usage)
  return NextResponse.json({reply:result.text,handoff:result.handoff})
 }catch(e){return jsonError(e instanceof Error?e.message:'AI request failed',502)}
}
