import {NextResponse} from 'next/server'
import {context,jsonError,apiFailure} from '@/lib/api'
export async function GET(){
 try{const ctx=await context();if('error' in ctx)return ctx.error
  const {data,error}=await ctx.db.from('ai_usage_log').select('mode,provider,model,prompt_tokens,completion_tokens,created_at').eq('workspace_id',ctx.workspace.id).order('created_at',{ascending:false}).limit(100)
  if(error)return jsonError(error.message,500)
  return NextResponse.json({usage:data||[]})
 }catch(e){return apiFailure(e)}
}
