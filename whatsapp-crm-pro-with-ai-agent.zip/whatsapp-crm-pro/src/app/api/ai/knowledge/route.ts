import {NextResponse} from 'next/server'
import {context,jsonBody,jsonError,apiFailure} from '@/lib/api'
export async function GET(){
 try{const ctx=await context();if('error' in ctx)return ctx.error
  const {data,error}=await ctx.db.from('ai_knowledge_documents').select('id,title,content,created_at').eq('workspace_id',ctx.workspace.id).order('created_at',{ascending:false}).limit(50)
  if(error)return jsonError(error.message,500)
  return NextResponse.json({documents:data||[]})
 }catch(e){return apiFailure(e)}
}
export async function POST(req:Request){
 try{const ctx=await context();if('error' in ctx)return ctx.error
  const b=await jsonBody(req);if(!b)return jsonError('Invalid JSON')
  const title=String(b.title||'').trim(),content=String(b.content||'').trim()
  if(!title||title.length>150||!content||content.length>20000)return jsonError('Title (1-150) and content (1-20000) required')
  const {count}=await ctx.db.from('ai_knowledge_documents').select('id',{count:'exact',head:true}).eq('workspace_id',ctx.workspace.id)
  if((count||0)>=50)return jsonError('Maximum 50 knowledge documents',409)
  const {data,error}=await ctx.db.from('ai_knowledge_documents').insert({workspace_id:ctx.workspace.id,title,content}).select('id,title,content,created_at').single()
  if(error)return jsonError(error.message,500)
  return NextResponse.json({document:data},{status:201})
 }catch(e){return apiFailure(e)}
}
export async function DELETE(req:Request){
 try{const ctx=await context();if('error' in ctx)return ctx.error
  const b=await jsonBody(req);if(!b||typeof b.id!=='string')return jsonError('Document id required')
  const {error}=await ctx.db.from('ai_knowledge_documents').delete().eq('workspace_id',ctx.workspace.id).eq('id',b.id)
  if(error)return jsonError(error.message,500)
  return NextResponse.json({ok:true})
 }catch(e){return apiFailure(e)}
}
