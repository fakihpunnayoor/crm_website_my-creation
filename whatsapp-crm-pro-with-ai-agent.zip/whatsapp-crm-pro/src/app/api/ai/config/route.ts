import { NextResponse } from 'next/server'
import { context,jsonBody,jsonError,apiFailure } from '@/lib/api'
export async function GET(){
  try {
    const ctx=await context();if('error' in ctx)return ctx.error
    const {data,error}=await ctx.db.from('ai_configs').select('provider,model,system_prompt,is_active,auto_reply_enabled,auto_reply_max_per_conversation').eq('workspace_id',ctx.workspace.id).maybeSingle()
    if(error)return jsonError(error.message,500)
    return NextResponse.json({configured:!!data,hasKey:Boolean(process.env.AI_API_KEY),config:data||{
      provider:process.env.AI_PROVIDER||'openai',model:process.env.AI_MODEL||'gpt-4o-mini',system_prompt:'',is_active:false,
      auto_reply_enabled:false,auto_reply_max_per_conversation:5
    }})
  }catch(e){return apiFailure(e)}
}
export async function POST(req:Request){
  try {
    const ctx=await context();if('error' in ctx)return ctx.error
    const b=await jsonBody(req);if(!b)return jsonError('Invalid JSON')
    const provider=String(b.provider||'openai')
    if(!['openai','anthropic','openai_compatible'].includes(provider))return jsonError('Invalid AI provider')
    const model=String(b.model||'').trim()
    if(!model || model.length>120 || !/^[\w.\-/ :]+$/.test(model))return jsonError('Invalid model identifier')
    const prompt=String(b.system_prompt||'').trim()
    if(prompt.length>12000)return jsonError('System prompt too long')
    const active=b.is_active===true,autoReply=b.auto_reply_enabled===true
    const max=Number(b.auto_reply_max_per_conversation||5)
    if(!Number.isInteger(max)||max<1||max>50)return jsonError('Reply limit must be 1-50')
    if((active||autoReply) && !process.env.AI_API_KEY?.trim())return jsonError('Add AI_API_KEY in server .env.local before enabling AI',409)
    if(provider==='openai_compatible'&&(!process.env.AI_BASE_URL||!process.env.AI_BASE_URL.startsWith('https://')))return jsonError('Set HTTPS AI_BASE_URL in .env.local',409)
    const {data,error}=await ctx.db.from('ai_configs').upsert({workspace_id:ctx.workspace.id,provider,model,
      system_prompt:prompt,is_active:active,auto_reply_enabled:active&&autoReply,
      auto_reply_max_per_conversation:max,updated_at:new Date().toISOString()},{onConflict:'workspace_id'}).select().single()
    if(error)return jsonError(error.message,500)
    return NextResponse.json({saved:true,config:{provider:data.provider,model:data.model,is_active:data.is_active,
      auto_reply_enabled:data.auto_reply_enabled,system_prompt:data.system_prompt,auto_reply_max_per_conversation:data.auto_reply_max_per_conversation}})
  }catch(e){return apiFailure(e)}
}
