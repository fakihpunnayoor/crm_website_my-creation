import {NextResponse} from 'next/server'
import {context,jsonBody,jsonError} from '@/lib/api'
import {buildContext,generateForWorkspace,recordUsage} from '@/lib/ai/service'
export async function POST(req:Request){
 const ctx=await context();if('error' in ctx)return ctx.error
 const b=await jsonBody(req);if(!b||typeof b.conversationId!=='string')return jsonError('conversationId required')
 const {data:conv}=await ctx.db.from('conversations').select('id').eq('workspace_id',ctx.workspace.id).eq('id',b.conversationId).maybeSingle()
 if(!conv)return jsonError('Conversation not found',404)
 try{
  const messages=await buildContext(ctx.db,ctx.workspace.id,conv.id)
  const result=await generateForWorkspace(ctx.db,ctx.workspace.id,messages,'draft')
  await recordUsage(ctx.db,ctx.workspace.id,'draft',result.config,result.usage,conv.id)
  return NextResponse.json({reply:result.text,handoff:result.handoff})
 }catch(e){return jsonError(e instanceof Error?e.message:'AI draft failed',502)}
}
