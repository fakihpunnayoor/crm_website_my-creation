import {context,apiFailure,jsonError,jsonBody,validPhone} from "@/lib/api";
import {NextResponse} from "next/server";
export async function GET(req:Request){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
  const q=new URL(req.url).searchParams.get("q")?.trim()||"";
  let query=ctx.db.from("contacts").select("id,workspace_id,phone_e164,name,opted_in,opted_in_at,blocked,tags,created_at").eq("workspace_id",ctx.workspace.id).order("created_at",{ascending:false}).limit(200);
  if(q) query=query.or(`name.ilike.%${q.replace(/[%,()]/g,"")}%,phone_e164.ilike.%${q.replace(/[%,()]/g,"")}%`);
  const {data,error}=await query;if(error)return jsonError(error.message,500);
  return NextResponse.json({contacts:data});
 }catch(e){return apiFailure(e);}
}
export async function POST(req:Request){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
  const body=await jsonBody(req);if(!body)return jsonError("Invalid JSON");
  const phone=validPhone(String(body.phone||""));
  const name=String(body.name||"").trim().slice(0,100);
  const consent=body.opted_in===true;
  if(!phone||!name)return jsonError("Name and international phone number required");
  if(consent && body.consent_confirmed!==true) return jsonError("Consent confirmation required");
  const {data:contact,error}=await ctx.db.from("contacts").insert({workspace_id:ctx.workspace.id,phone_e164:phone,name,opted_in:consent,opted_in_at:consent?new Date().toISOString():null}).select().single();
  if(error)return jsonError(error.code==="23505"?"This number is already in Contacts":error.message,409);
  // Database trigger creates the matching conversation atomically.
  return NextResponse.json({contact},{status:201});
 }catch(e){return apiFailure(e);}
}
export async function PATCH(req:Request){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
  const b=await jsonBody(req);if(!b||typeof b.id!=="string")return jsonError("Contact ID required");
  const changes:Record<string,unknown>={};
  if(typeof b.name==="string")changes.name=b.name.trim().slice(0,100);
  if(typeof b.blocked==="boolean")changes.blocked=b.blocked;
  if(typeof b.opted_in==="boolean") {
    if(b.opted_in && b.consent_confirmed!==true)return jsonError("Explicit consent confirmation required");
    changes.opted_in=b.opted_in;changes.opted_in_at=b.opted_in?new Date().toISOString():null;
  }
  if(Object.keys(changes).length===0)return jsonError("Nothing to update");
  const {data,error}=await ctx.db.from("contacts").update(changes).eq("id",b.id).eq("workspace_id",ctx.workspace.id).select().maybeSingle();
  if(error)return jsonError(error.message,500);if(!data)return jsonError("Contact not found",404);
  return NextResponse.json({contact:data});
 }catch(e){return apiFailure(e);}
}
