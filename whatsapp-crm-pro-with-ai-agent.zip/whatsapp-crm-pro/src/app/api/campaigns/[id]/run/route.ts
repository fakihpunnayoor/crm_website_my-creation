import {context,jsonError,apiFailure} from "@/lib/api";
import {adminSupabase} from "@/lib/supabase/server";
import {sendTemplate} from "@/lib/meta";
import {NextResponse} from "next/server";
export const maxDuration=60;
const BATCH=10;
export async function POST(_req:Request,{params}:{params:Promise<{id:string}>}){
 try{
  const ctx=await context();if("error" in ctx)return ctx.error;
  const {id}=await params;
  const {data:campaign,error}=await ctx.db.from("campaigns").select("*").eq("id",id).eq("workspace_id",ctx.workspace.id).maybeSingle();
  if(error||!campaign)return jsonError("Campaign not found",404);
  const admin=adminSupabase();
  // Select unclaimed, eligible recipients in Postgres without a fixed page cap.
  const {data:targets,error:targetsErr}=await admin.rpc("next_campaign_targets",{
    campaign_uuid:id,requested_count:BATCH
  });
  if(targetsErr)return jsonError("Campaign audience query failed: "+targetsErr.message,500);
  const group=(targets||[]) as {contact_id:string;phone_e164:string}[];
  if(group.length===0){
    await admin.from("campaigns").update({status:"completed"}).eq("id",id).eq("workspace_id",ctx.workspace.id);
    return NextResponse.json({sent:0,failed:0,moreAvailable:false,detail:"No unprocessed opted-in contacts remain"});
  }
  await admin.from("campaigns").update({status:"running"}).eq("id",id).eq("workspace_id",ctx.workspace.id);
  let sent=0,failed=0;
  for(const contact of group){
    // Insert a claim BEFORE contacting Meta; unique(campaign_id,contact_id) prevents duplicate sends.
    const {data:claim,error:claimErr}=await admin.from("campaign_deliveries").insert({workspace_id:ctx.workspace.id,campaign_id:id,contact_id:contact.contact_id,status:"pending"}).select("id").single();
    if(claimErr||!claim)continue;
    try{
      const result=await sendTemplate(contact.phone_e164,campaign.template_name,campaign.template_language);
      const externalId=String(result?.messages?.[0]?.id||"");
      await admin.from("campaign_deliveries").update({status:"accepted",external_id:externalId||null}).eq("id",claim.id);
      const {data:conv}=await admin.from("conversations").select("id").eq("workspace_id",ctx.workspace.id).eq("contact_id",contact.contact_id).maybeSingle();
      if(conv){
        const note=`Template: ${campaign.template_name}`;
        await admin.from("messages").insert({workspace_id:ctx.workspace.id,conversation_id:conv.id,contact_id:contact.contact_id,external_id:externalId||null,direction:"outbound",kind:"template",body:note,status:"accepted"});
        await admin.from("conversations").update({last_message_at:new Date().toISOString(),last_preview:note}).eq("id",conv.id);
      }
      sent++;
    }catch(e){failed++;
      await admin.from("campaign_deliveries").update({status:"failed",error_text:e instanceof Error?e.message:"Meta request failed"}).eq("id",claim.id);
    }
  }
  // Re-query AFTER claims are written, so "complete" isn't based on a stale
  // page or the Supabase default 1,000-row response ceiling.
  const {data:next,error:nextErr}=await admin.rpc("next_campaign_targets",{
    campaign_uuid:id,requested_count:1
  });
  if(nextErr)return jsonError("Batch sent, but remaining-recipient check failed; inspect logs before retrying",502);
  const moreAvailable=(next||[]).length>0;
  if(!moreAvailable)await admin.from("campaigns").update({status:"completed"}).eq("id",id).eq("workspace_id",ctx.workspace.id);
  return NextResponse.json({sent,failed,moreAvailable,detail:moreAvailable?"Eligible contacts remain; send the next manual batch when ready":"No unclaimed eligible contacts remain. Review failed/pending claims in Supabase."});
 }catch(e){return apiFailure(e);}
}
