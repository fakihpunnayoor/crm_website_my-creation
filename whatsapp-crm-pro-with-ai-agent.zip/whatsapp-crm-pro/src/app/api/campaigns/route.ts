import {context,apiFailure,jsonError,jsonBody} from "@/lib/api";
import {NextResponse} from "next/server";
export async function GET(){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
 const [{data,error},{count}]=await Promise.all([
  ctx.db.from("campaigns").select("*").eq("workspace_id",ctx.workspace.id).order("created_at",{ascending:false}),
  ctx.db.from("contacts").select("id",{count:"exact",head:true}).eq("workspace_id",ctx.workspace.id).eq("opted_in",true).eq("blocked",false)
 ]);
 if(error)return jsonError(error.message,500);return NextResponse.json({campaigns:data,eligibleContacts:count||0});
 }catch(e){return apiFailure(e);}
}
export async function POST(req:Request){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
 const b=await jsonBody(req);if(!b)return jsonError("Invalid JSON");
 const name=String(b.name||"").trim().slice(0,100);
 const template=String(b.template_name||"").trim(),lang=String(b.template_language||"en_US").trim();
 if(!name||!/^\w{1,512}$/.test(template)||!/^[a-z]{2,3}(_[A-Z]{2})?$/.test(lang))return jsonError("Valid campaign name, approved template name, and language required");
 const {data,error}=await ctx.db.from("campaigns").insert({workspace_id:ctx.workspace.id,name,template_name:template,template_language:lang}).select().single();
 if(error)return jsonError(error.message,500);return NextResponse.json({campaign:data},{status:201});
 }catch(e){return apiFailure(e);}
}
