import {context,jsonError,apiFailure,jsonBody} from "@/lib/api";
import {adminSupabase} from "@/lib/supabase/server";
import {sendText} from "@/lib/meta";
import {NextResponse} from "next/server";
export async function GET(req:Request){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
 const id=new URL(req.url).searchParams.get("conversationId");if(!id)return jsonError("conversationId required");
 const {data:conv}=await ctx.db.from("conversations").select("id").eq("id",id).eq("workspace_id",ctx.workspace.id).maybeSingle();
 if(!conv)return jsonError("Conversation not found",404);
 const {data,error}=await ctx.db.from("messages").select("*").eq("conversation_id",id).eq("workspace_id",ctx.workspace.id).order("created_at",{ascending:true}).limit(300);
 if(error)return jsonError(error.message,500);
 return NextResponse.json({messages:data});
 }catch(e){return apiFailure(e);}
}
export async function POST(req:Request){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
 const body=await jsonBody(req);
 if(!body||typeof body.conversationId!=="string"||typeof body.text!=="string")return jsonError("conversationId and text required");
 const text=body.text.trim();if(!text||text.length>4096)return jsonError("Text length must be 1–4096 characters");
 const {data:conv,error:err}=await ctx.db.from("conversations").select("id,contact_id,contacts(id,phone_e164,blocked)").eq("id",body.conversationId).eq("workspace_id",ctx.workspace.id).maybeSingle();
 if(err||!conv)return jsonError("Conversation not found",404);
 // Supabase nested relation is an object in this schema.
 const c=conv.contacts as unknown as {id:string;phone_e164:string;blocked:boolean}|null;
 if(!c||c.blocked)return jsonError("Contact is blocked or missing",403);
 // WhatsApp free-form messaging is only permitted in an open customer service window.
 const {data:lastInbound}=await ctx.db.from("messages").select("created_at").eq("contact_id",c.id).eq("workspace_id",ctx.workspace.id).eq("direction","inbound").order("created_at",{ascending:false}).limit(1).maybeSingle();
 if(!lastInbound||Date.now()-new Date(lastInbound.created_at).getTime()>23*60*60*1000)
   return jsonError("Customer service window closed. Use an approved template campaign instead.",422);
 const result=await sendText(c.phone_e164,text);
 const externalId=String(result?.messages?.[0]?.id||"");
 const admin=adminSupabase();
 const {data:message,error:saveError}=await admin.from("messages").insert({workspace_id:ctx.workspace.id,conversation_id:conv.id,contact_id:c.id,direction:"outbound",kind:"text",body:text,status:"accepted",external_id:externalId||null}).select().single();
 if(saveError) return jsonError("Meta accepted the message but database save failed. Do not resend without checking: "+saveError.message,502);
 await admin.from("conversations").update({last_preview:text,last_message_at:new Date().toISOString()}).eq("id",conv.id).eq("workspace_id",ctx.workspace.id);
 return NextResponse.json({message},{status:201});
 }catch(e){return jsonError(e instanceof Error?e.message:"Send failed",502);}
}
