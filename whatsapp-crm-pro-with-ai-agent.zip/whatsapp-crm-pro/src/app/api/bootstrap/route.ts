import { serverSupabase } from "@/lib/supabase/server";
import { jsonError } from "@/lib/api";
import { NextResponse } from "next/server";
export async function POST(){
  const db=await serverSupabase();
  const {data:{user}}=await db.auth.getUser();
  if(!user) return jsonError("Sign in first",401);
  if(!process.env.CRM_OWNER_USER_ID || process.env.CRM_OWNER_USER_ID!==user.id) return jsonError("Unauthorized owner",403);
  const {data:existing,error:lookupErr}=await db.from("workspaces").select("id").eq("owner_id",user.id).maybeSingle();
  if(lookupErr) return jsonError("Run sql/schema.sql in Supabase SQL Editor",500);
  if(existing) return NextResponse.json({ok:true,workspaceId:existing.id});
  const {data,error}=await db.from("workspaces").insert({owner_id:user.id,name:"My WhatsApp Workspace"}).select("id").single();
  if(error) {
    const {data:retry}=await db.from("workspaces").select("id").eq("owner_id",user.id).maybeSingle();
    if(retry) return NextResponse.json({ok:true,workspaceId:retry.id});
    return jsonError(error.message,500);
  }
  return NextResponse.json({ok:true,workspaceId:data.id});
}
