import {context,apiFailure} from "@/lib/api";
import {checkMeta,checkSubscription} from "@/lib/meta";
import {NextResponse} from "next/server";
export async function GET(){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
 const configured=Boolean(process.env.META_ACCESS_TOKEN&&process.env.META_PHONE_NUMBER_ID&&process.env.META_APP_SECRET&&process.env.META_WEBHOOK_VERIFY_TOKEN&&process.env.META_WABA_ID);
 const data:{configured:boolean;phoneId:string|null;webhookPath:string;apiOk:boolean;apiMessage:string;subscribedApps:number|null;inboundSeen:number;outboundSeen:number}={
  configured,phoneId:process.env.META_PHONE_NUMBER_ID||null,webhookPath:"/api/webhooks/whatsapp",apiOk:false,apiMessage:"Not checked",subscribedApps:null,inboundSeen:0,outboundSeen:0
 };
 if(configured){
  try{const meta=await checkMeta();data.apiOk=true;data.apiMessage=`Connected • ${meta.display_phone_number||meta.verified_name||"phone found"}`;}
  catch(e){data.apiMessage=e instanceof Error?e.message:"Meta lookup failed";}
  try{const subs=await checkSubscription();data.subscribedApps=Array.isArray(subs.data)?subs.data.length:0;}
  catch{/* Optional subscription check; not evidence of phone registration */}
 }
 const [inbound,outbound]=await Promise.all([
  ctx.db.from("messages").select("id",{count:"exact",head:true}).eq("workspace_id",ctx.workspace.id).eq("direction","inbound"),
  ctx.db.from("messages").select("id",{count:"exact",head:true}).eq("workspace_id",ctx.workspace.id).eq("direction","outbound")
 ]);
 data.inboundSeen=inbound.count||0;data.outboundSeen=outbound.count||0;
 return NextResponse.json(data,{headers:{"Cache-Control":"no-store"}});
 }catch(e){return apiFailure(e);}
}
