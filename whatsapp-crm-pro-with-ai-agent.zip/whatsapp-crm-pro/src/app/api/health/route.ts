import {NextResponse} from "next/server";
export async function GET(){return NextResponse.json({status:"ok",app:"WhatsApp CRM Pro",timestamp:new Date().toISOString()});}
