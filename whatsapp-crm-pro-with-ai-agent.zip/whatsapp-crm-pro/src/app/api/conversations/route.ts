import {context,jsonError,apiFailure,jsonBody} from "@/lib/api";
import {NextResponse} from "next/server";
export async function GET(){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
 const {data,error}=await ctx.db.from("conversations").select("id,workspace_id,contact_id,unread_count,last_message_at,last_preview,status,ai_paused,ai_reply_count,ai_handoff_summary,contacts(id,name,phone_e164)").eq("workspace_id",ctx.workspace.id).order("last_message_at",{ascending:false,nullsFirst:false}).limit(200);
 if(error)return jsonError(error.message,500);
 return NextResponse.json({conversations:data});
 }catch(e){return apiFailure(e);}
}
export async function POST(req:Request){
 try{const ctx=await context();if("error" in ctx)return ctx.error;
  const body=await jsonBody(req);if(!body||typeof body.id!=="string")return jsonError("Conversation id required");
  const {error}=await ctx.db.from("conversations").update({unread_count:0}).eq("id",body.id).eq("workspace_id",ctx.workspace.id);
  if(error)return jsonError(error.message,500);return NextResponse.json({ok:true});
 }catch(e){return apiFailure(e);}
}
