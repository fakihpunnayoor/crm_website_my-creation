# Architecture and API Reference

## Deployment topology

```mermaid
flowchart TB
    A[CRM owner in browser] -->|Supabase Auth cookies| B[Next.js App Router]
    B -->|Authenticated API requests| C[Server-side owner verification]
    C -->|RLS user client| D[(Supabase PostgreSQL)]
    C -->|Meta system user token| E[Meta WhatsApp Graph API]
    E -->|Signed POST webhooks| F[Next.js webhook endpoint]
    F -->|HMAC-SHA256 verified| G[Privileged event processor]
    G -->|Service role| D
    G -->|Eligible keyword auto-reply| E
```

## Relational data model

```mermaid
erDiagram
  workspaces ||--o{ contacts : has
  workspaces ||--o{ conversations : has
  contacts ||--o| conversations : has
  conversations ||--o{ messages : contains
  workspaces ||--o{ campaigns : has
  campaigns ||--o{ campaign_deliveries : targets
  contacts ||--o{ campaign_deliveries : gets
  workspaces ||--o{ automation_rules : has
  contacts ||--o{ automation_runs : triggers
  automation_rules ||--o{ automation_runs : executes
```

`workspaces.owner_id` is the Supabase Auth UUID. Every user-facing table has row-level security. The deployment only allows the configured UUID in `CRM_OWNER_USER_ID` to access its API. Cross-workspace contact/conversation references use composite foreign keys. The service-role key is used only on trusted servers to ingest verified Meta events and persist outbound send status.

## Browser page routes

| Route | Responsibility |
| --- | --- |
| `/login` | Email/password sign-in |
| `/dashboard` | KPIs and recent conversations |
| `/inbox` | Conversations, message history, send free-form replies |
| `/contacts` | Create, find, block/unblock contacts and manually document opt-in |
| `/campaigns` | Create approved-template campaign, manually send batches |
| `/automations` | Create/toggle/delete keyword reply rules |
| `/settings` | Meta reachability, webhook URL and message counts |

## Backend API routes

Authenticated JSON endpoints, all require a valid owner session except health and webhook:

| Method | Path | Purpose |
| --- | --- | --- |
| `POST` | `/api/bootstrap` | Create current owner's workspace if absent |
| `GET` | `/api/dashboard` | KPI counts and latest conversations |
| `GET` | `/api/contacts` | List contacts (`?q=` optional) |
| `POST` | `/api/contacts` | Add contact `{name, phone, opted_in, consent_confirmed}` |
| `PATCH` | `/api/contacts` | Update `{id,name?,blocked?,opted_in?,consent_confirmed?}` |
| `GET` | `/api/conversations` | List conversations |
| `POST` | `/api/conversations` | Clear unread count `{id}` |
| `GET` | `/api/messages?conversationId=...` | List messages |
| `POST` | `/api/messages` | Send customer-window text `{conversationId,text}` |
| `GET` | `/api/campaigns` | Campaigns and consented recipient count |
| `POST` | `/api/campaigns` | Draft campaign `{name,template_name,template_language}` |
| `POST` | `/api/campaigns/:id/run` | Claim and send up to 10 opted-in recipients |
| `GET` | `/api/automation-rules` | List keyword rules |
| `POST` | `/api/automation-rules` | Add `{name,keyword,reply_text}` |
| `PATCH` | `/api/automation-rules` | Toggle `{id,enabled}` |
| `DELETE` | `/api/automation-rules` | Delete `{id}` |
| `GET` | `/api/connection` | Reachability checks and event counts |
| `GET` | `/api/health` | Public non-sensitive health ping |
| `GET` | `/api/webhooks/whatsapp` | Meta verification challenge |
| `POST` | `/api/webhooks/whatsapp` | Signed webhook ingest and auto-replies |

## Event ingestion design

1. Meta POSTs to the public webhook path. The server keeps the raw body and checks `X-Hub-Signature-256` with `META_APP_SECRET` in constant time.
2. Only signed `messages` events whose `metadata.phone_number_id` matches configured `META_PHONE_NUMBER_ID` are processed.
3. `statuses` events update outbound message statuses by Meta external message ID.
4. New inbound messages are deduplicated by unique `external_id`, attached to a known-or-new contact and conversation, and surfaced in the inbox.
5. Incoming exact marketing opt-out requests revoke `opted_in` before the campaign scanner can send new batches.
6. Other new inbound text can trigger at most one enabled keyword auto-reply, subject to a cooldown.
7. Processing errors return HTTP 500 for Meta retry. Duplicate inbound IDs are ignored to limit repeated effects.

## Security controls

- Every API mutation requires authenticated owner cookies, checked via Supabase `auth.getUser()`.
- Protected application queries use a scoped Supabase SSR user client; RLS is enabled in SQL.
- Privileged webhook operations use service role **only after** HMAC verification and configured Phone Number ID checks.
- No service-role, Meta token or app secret uses the `NEXT_PUBLIC_` prefix.
- No public account registration endpoint is provided by this application.
- Conversation lookups always check workspace scope; outbound free-form replies are limited to a conservative 23-hour customer-service window.
- Template campaign sends require manual operator initiation and are consent-filtered.

## Boundaries

For production, add staff RBAC, background queue/worker for Meta webhook and bulk sends, atomic concurrency controls for counters/cooldowns, recipient opt-in audit evidence, data deletion/retention workflows, status and error dashboards, monitoring, and full end-to-end tests. This source does not claim those components already exist.

## Code audit corrections (2026-11-21)

- Added a Next.js 16 Supabase Proxy to refresh auth cookies on both request and response. Public Meta webhook and health paths bypass this auth Proxy.
- Added a Postgres `next_campaign_targets` SQL function, callable by service_role only, to select unclaimed recipients without the original 1,000-row limitation.
- Added an `AFTER INSERT` contact trigger to create its conversation in the same transaction.
- These are source changes and static/unit-tested only. No claim of live Meta, Supabase, or browser end-to-end certification is made.


## AI Agents (v1.1.0 add-on)

`/agents` → authenticated `/api/ai/*` routes → per-workspace Supabase config/knowledge/usage. Provider credentials remain in server env. Inbound verified Meta webhook persists the message, then schedules a best-effort `after()` AI task. Keyword automations take priority. The task reads recent conversation context and lexical knowledge chunks, calls the configured LLM, optionally records human handoff, atomically claims the reply slot, sends with Meta Cloud API, and stores outbound message. Replays are deduplicated by Meta external message IDs and `ai_reply_attempts`. See `AI_AGENT_SETUP.md` for limitations.
