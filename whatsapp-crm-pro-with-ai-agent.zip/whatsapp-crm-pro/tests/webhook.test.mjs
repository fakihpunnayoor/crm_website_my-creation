import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {verifyMetaSignature} from '../src/lib/meta.ts';
const secret='test-only-secret';
const payload=JSON.stringify({object:'whatsapp_business_account',entry:[]});
const signed='sha256='+createHmac('sha256',secret).update(payload).digest('hex');
test('valid webhook HMAC is accepted',()=>assert.equal(verifyMetaSignature(payload,signed,secret),true));
test('payload tampering is rejected',()=>assert.equal(verifyMetaSignature(payload+'x',signed,secret),false));
test('unsigned webhook is rejected',()=>assert.equal(verifyMetaSignature(payload,null,secret),false));
test('bad signature length is rejected',()=>assert.equal(verifyMetaSignature(payload,'sha256=beef',secret),false));
test('missing secret is rejected',()=>assert.equal(verifyMetaSignature(payload,signed,''),false));
test('schema enables RLS on all CRM tables',()=>{
 const sql=readFileSync(new URL('../sql/schema.sql',import.meta.url),'utf8');
 for(const name of ['workspaces','contacts','conversations','messages','campaigns','campaign_deliveries','automation_rules','automation_runs'])
  assert.match(sql,new RegExp(`alter table public\\.${name} enable row level security;`));
});

test('Supabase session-refresh Proxy is present and excludes the public Meta webhook',()=>{
 const proxy=readFileSync(new URL('../src/proxy.ts',import.meta.url),'utf8');
 const utility=readFileSync(new URL('../src/lib/supabase/proxy.ts',import.meta.url),'utf8');
 assert.match(proxy,/api\/webhooks\/whatsapp/);
 assert.match(utility,/supabase\.auth\.getClaims\(\)/);
 assert.match(utility,/response\.cookies\.set/);
});
test('campaign recipient lookup is paged in the database, not capped at 1,000 contacts',()=>{
 const sql=readFileSync(new URL('../sql/schema.sql',import.meta.url),'utf8');
 const campaign=readFileSync(new URL('../src/app/api/campaigns/[id]/run/route.ts',import.meta.url),'utf8');
 assert.match(sql,/function public\.next_campaign_targets/);
 assert.match(campaign,/rpc\("next_campaign_targets"/);
 assert.doesNotMatch(campaign,/\.limit\(1000\)/);
});
test('contact insert uses an atomic conversation trigger',()=>{
 const sql=readFileSync(new URL('../sql/schema.sql',import.meta.url),'utf8');
 assert.match(sql,/create trigger contact_conversation_on_insert/);
});
