import test from 'node:test'
import assert from 'node:assert/strict'
import {readFileSync} from 'node:fs'
import {fileURLToPath} from 'node:url'
import {resolve,dirname} from 'node:path'
import {chunkText} from '../src/lib/ai/chunk.ts'
import {buildSystemPrompt,HANDOFF_SENTINEL} from '../src/lib/ai/defaults.ts'
import {latestUserMessage} from '../src/lib/ai/query.ts'
const cwd=resolve(dirname(fileURLToPath(import.meta.url)),'..')
const read=(name)=>readFileSync(resolve(cwd,name),'utf8')
test('source-derived knowledge chunker preserves short paragraphs',()=>{
 assert.deepEqual(chunkText('Q: price?\nA: ask us.\n\nQ: shipping?\nA: varies.',{maxChars:32}),['Q: price?\nA: ask us.','Q: shipping?\nA: varies.'])
})
test('long knowledge is chunked to max chars',()=>{
 const result=chunkText('z'.repeat(140),{maxChars:55});assert.equal(result.length,3);assert.ok(result.every(s=>s.length<=55))
})
test('AI auto-reply instruction includes human handoff',()=>{
 const text=buildSystemPrompt({userPrompt:'Only facts found in knowledge',mode:'auto_reply',knowledge:['Return window 7 days']})
 assert.ok(text.includes(HANDOFF_SENTINEL));assert.ok(text.includes('Return window 7 days'))
})
test('knowledge context uses latest inbound user question',()=>{
 assert.equal(latestUserMessage([{role:'user',content:'price?'},{role:'assistant',content:'check'},{role:'user',content:'XL?'}]),'XL?')
})
test('AI schema enforces workspace RLS and excludes credentials',()=>{
 const schema=read('sql/ai-agent-migration.sql')
 for(const name of ['ai_configs','ai_knowledge_documents','ai_usage_log','ai_reply_attempts'])assert.match(schema,new RegExp(`alter table public\\.${name} enable row level security`))
 assert.ok(!/api_key\s+text/.test(schema))
 assert.match(schema,/create or replace function public\.claim_ai_reply_slot/)
 assert.match(schema,/grant execute on function public\.claim_ai_reply_slot\(uuid,integer\) to service_role/)
})
test('inbound webhook prioritizes keyword rules before AI and uses after()',()=>{
 const route=read('src/app/api/webhooks/whatsapp/route.ts')
 assert.match(route,/if\(rule\)\{/)
 assert.match(route,/after\(async\(\)=>\{await dispatchInboundToAi/)
 assert.match(route,/verifyMetaSignature/)
})
test('AI auto replies skip blocked or opted out paths in webhook',()=>{
 const route=read('src/app/api/webhooks/whatsapp/route.ts')
 assert.match(route,/contact\.blocked/)
 assert.match(route,/stop\|unsubscribe/)
})
test('AI provider credentials are server-only and not copied from uploaded project',()=>{
 const env=read('.env.example');assert.match(env,/AI_API_KEY=/)
 assert.ok(!read('src/app/(dashboard)/agents/page.tsx').includes('process.env.AI_API_KEY'))
 assert.ok(!read('sql/ai-agent-migration.sql').includes('api_key text'))
})
