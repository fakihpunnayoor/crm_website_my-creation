import {test} from 'node:test';
import assert from 'node:assert/strict';
import {sendText,sendTemplate,checkMeta,checkSubscription} from '../src/lib/meta.ts';

function withFakeMeta(response,{status=200}={}){
 const oldFetch=globalThis.fetch;
 const old={};
 for(const name of ['META_ACCESS_TOKEN','META_PHONE_NUMBER_ID','META_WABA_ID','META_GRAPH_VERSION'])old[name]=process.env[name];
 Object.assign(process.env,{META_ACCESS_TOKEN:'unit-test-token',META_PHONE_NUMBER_ID:'1234567890',META_WABA_ID:'987654321',META_GRAPH_VERSION:'v27.0'});
 const calls=[];
 globalThis.fetch=async (url,init)=>{
   calls.push({url:String(url),init});
   return {ok:status>=200&&status<300,status,async json(){return response;}};
 };
 return {calls,restore(){globalThis.fetch=oldFetch;for(const [key,value] of Object.entries(old)){if(value===undefined)delete process.env[key];else process.env[key]=value;}}};
}

test('Meta sends a text message to the configured Graph API phone ID', async()=>{
 const mock=withFakeMeta({messages:[{id:'wamid.fake'}]});
 try{
  const result=await sendText('919999000000','Hello from CRM');
  assert.equal(result.messages[0].id,'wamid.fake');
  assert.equal(mock.calls.length,1);
  assert.equal(mock.calls[0].url,'https://graph.facebook.com/v27.0/1234567890/messages');
  assert.equal(mock.calls[0].init.method,'POST');
  assert.equal(mock.calls[0].init.headers.Authorization,'Bearer unit-test-token');
  const payload=JSON.parse(mock.calls[0].init.body);
  assert.deepEqual({to:payload.to,type:payload.type,text:payload.text},
    {to:'919999000000',type:'text',text:{preview_url:false,body:'Hello from CRM'}});
 }finally{mock.restore();}
});

test('Meta sends the correct approved-template request structure', async()=>{
 const mock=withFakeMeta({messages:[{id:'wamid.template'}]});
 try{
  await sendTemplate('919999000000','weekend_offer','en_US');
  const payload=JSON.parse(mock.calls[0].init.body);
  assert.equal(payload.type,'template');
  assert.deepEqual(payload.template,{name:'weekend_offer',language:{code:'en_US'}});
 }finally{mock.restore();}
});

test('Meta Graph errors are surfaced rather than reporting false success', async()=>{
 const mock=withFakeMeta({error:{message:'Mock invalid token'}},{status:401});
 try{await assert.rejects(()=>checkMeta(),/Meta: Mock invalid token/);}finally{mock.restore();}
});

test('Subscription checks call the WABA subscribed_apps path',async()=>{
 const mock=withFakeMeta({data:[{id:'test-app'}]});
 try{await checkSubscription();assert.equal(mock.calls[0].url,'https://graph.facebook.com/v27.0/987654321/subscribed_apps');}
 finally{mock.restore();}
});
