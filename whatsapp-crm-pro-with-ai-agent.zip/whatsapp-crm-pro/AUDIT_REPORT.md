# Pulse WhatsApp CRM — Source Code QA Report

**Review date:** 21 November 2026  
**Result:** **Source-audited MVP, NOT production certified**. It is not possible to guarantee 100% correctness without live credentials, a clean database migration, a successful dependency installation/build, and end-to-end Meta WhatsApp webhook tests.

## Fixes made in this reviewed ZIP

1. Added **Next.js 16 `src/proxy.ts`** and Supabase SSR cookie refresh helper with `getClaims`, according to official Supabase guidance. The public Meta webhook and health paths are exempt from interactive-login session processing.
2. Replaced the **first 1,000 campaign contacts limit** with a database-side `next_campaign_targets` function that selects unclaimed, currently opted-in and unblocked recipients. Only the server's service role can execute it.
3. Added an **atomic contact -> conversation trigger**. Contact insertion no longer leaves behind a partially created contact on a separate conversation-insert failure.
4. Improved outbound status semantics: `accepted` means Meta accepted the API request; `sent`, `delivered`, `read` and `failed` should arrive via signed Meta status webhooks. Status webhooks now update relevant campaign delivery rows too.
5. Renamed the UI sidebar **Team Inbox** to **Inbox**, because this MVP is owner-only and does **not** implement team accounts or assignments.
6. Expanded tests to check mock Meta send payloads, API errors, session proxy source, RLS presence, campaign eligibility function presence, and the contact trigger.

## Local checks performed

| Check | Outcome | Meaning / limitation |
| --- | --- | --- |
| `npm test` (Node 22) | **13/13 passed** | Unit tests include HMAC and mocked outbound Meta API requests; not a live Meta connection |
| TypeScript parser | **34 TypeScript/TSX source/config files parsed; 0 syntax errors** | Checks grammar only, **not** type checking or a Next.js build |
| RLS in all 8 core tables | **Present in SQL** | Policies were not exercised against PostgreSQL |
| Schema: RPC, trigger and RLS | **Static checked** | SQL migration never executed in a fresh Supabase database |
| Package versions | **Pinned in `package.json`** | Lockfile was not generated due to unavailable npm registry |
| Actual `npm install`, `npm run build` | **NOT verified** | Container could not access the required npm packages, so full compile/build impossible |
| Browser login / navigation | **NOT verified** | Requires running Next.js + Supabase Auth |
| Live Meta callback verification, signed POST | **NOT verified** | Requires a public HTTPS callback and Meta app setup |
| Live customer inbound / replies / template sends | **NOT verified** | Requires working phone registration, access token, subscription and test customer consent |
| Load/concurrency, disaster recovery, compliance | **NOT verified** | Requires further implementation and stress tests |

## Required real-world tests BEFORE real customer use

- [ ] Run `npm install`, `npm test`, `npm run typecheck`, `npm run build` successfully with Node.js 22+.
- [ ] Create a **new, dedicated Supabase project** and run `sql/schema.sql` from start to finish; verify all 8 tables, trigger, RPC function, owner workspace and policies.
- [ ] Verify an unauthorized Supabase user cannot read or mutate the owner's workspace.
- [ ] Create a contact in the UI; verify a conversation exists automatically; verify blocked and opted-in flags behave as expected.
- [ ] Sign in, leave the session long enough to refresh, and confirm the session remains functional.
- [ ] Deploy to stable HTTPS, configure Meta webhook GET challenge and subscribe the WABA app to `messages`.
- [ ] Test a **real inbound message** from a number you control; confirm it appears once in Supabase and the Inbox. A generic Meta Dashboard **Test** event may not represent an actual customer message.
- [ ] Test a WhatsApp reply within the 24-hour service window; verify initial API acceptance and subsequent sent/delivered/read webhook status.
- [ ] Test an approved **no-variable** message template for **one opted-in recipient**; check failed, blocked, unsubscribed and repeat-send cases.
- [ ] Check phone status, app Live/Published state, production rate limits, logging, backups, opt-in evidence, retention and data protection obligations.

## Important unresolved MVP limitations

- **Owner only** — there is no team-member authentication or agent assignment.
- Campaign dispatch is **manual batches of 10**, not a durable queued sender. Failed/pending claims require operator review and cannot be automatically retried safely. Large batches may exceed serverless time limits.
- Inbound webhook processing performs database writes and automation replies inline; a queue, concurrency-safe unread counters, deduplication around all side effects and resilience tests are advisable before scale.
- Only text and basic inbound placeholders; attachments, template variables and an actual message-template management UI are not implemented.
- Opt-in is a manual attestation; auditable consent evidence, retention/export/deletion and a complete marketing compliance workflow are not implemented.
- Successful Meta API reachability does **not** by itself prove phone number registration, WABA webhook delivery or that the Meta app is live.

**Conclusion:** The fixes improve correctness, but passing 13 local tests is **not** 100% proof of production reliability. Use this as a reviewed starter and complete the live QA checklist before deployment to customers.
