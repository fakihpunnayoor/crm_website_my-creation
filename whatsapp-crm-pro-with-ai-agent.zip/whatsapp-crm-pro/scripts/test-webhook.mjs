// Local-only signed webhook smoke test. Use Node 22 with: node --env-file=.env.local scripts/test-webhook.mjs
import {createHmac} from 'node:crypto';
const secret=process.env.META_APP_SECRET;
const phoneId=process.env.META_PHONE_NUMBER_ID;
const from=process.env.TEST_CUSTOMER_WA_ID;
const base=process.env.TEST_CRM_URL||'http://localhost:3000';
if(!secret||!phoneId||!from||!/^\d{8,15}$/.test(from)||!/^http:\/\/localhost(:\d+)?$/.test(base)) {
 console.error('Required: META_APP_SECRET, META_PHONE_NUMBER_ID, TEST_CUSTOMER_WA_ID (digits), and local TEST_CRM_URL (http://localhost:3000). This script refuses non-local URLs.');
 process.exit(1);
}
const body=JSON.stringify({object:'whatsapp_business_account',entry:[{id:'example',changes:[{field:'messages',value:{messaging_product:'whatsapp',metadata:{phone_number_id:phoneId},contacts:[{wa_id:from,profile:{name:'Local Webhook Test'}}],messages:[{id:`wamid.LOCAL_TEST_${Date.now()}`,from,type:'text',timestamp:String(Math.floor(Date.now()/1000)),text:{body:'Local integration test (not from Meta)'}}]}}]}]});
const signature='sha256='+createHmac('sha256',secret).update(body).digest('hex');
const result=await fetch(base+'/api/webhooks/whatsapp',{method:'POST',headers:{'Content-Type':'application/json','X-Hub-Signature-256':signature},body});
console.log(`HTTP ${result.status}`,await result.text());
console.log('Local signed-payload check only. It does NOT prove Meta published events can reach this server.');
