# Pulse CRM + AI Agents (v1.1.0)

**Upgraded from the audited Pulse CRM.** Start with **[AI_AGENT_SETUP.md](AI_AGENT_SETUP.md)** for migration/setup/test instructions. This package adds the AI Agent feature adapted from the uploaded WACRM source. Existing CRM features remain in place.

---

# Pulse CRM — WhatsApp Business CRM (Next.js + Supabase + Meta Cloud API)

A **source-audited MVP / starter**, designed for **one business owner per deployment**. See [AUDIT_REPORT.md](AUDIT_REPORT.md) for the exact completed checks, fixes and unresolved production risks. Includes a responsive dashboard, owner login, WhatsApp inbox, contact management, consent-aware template campaigns, keyword auto-replies, Meta webhook receiver, and Supabase RLS.

> **Important:** This is an implementation starter, not a claim of production certification. The project has not been connected to your Meta or Supabase accounts; the added SQL functions and trigger have not been executed on a live database. Complete the configuration, run migrations in a **new dedicated Supabase project**, test the workflows and security, and complete Meta publication/verification as required before real customers use it. No secrets are included.

## Architecture

```
Browser (React 19 / Next.js 16)
  ├─ Login via Supabase Auth (cookie-based @supabase/ssr; Next.js Proxy refresh)
  ├─ CRM pages -> authenticated Next.js API routes -> Supabase (RLS)
  └─ No Meta or Supabase service-role secrets in browser

Meta WhatsApp Cloud API
  ├─ Outbound: /api/messages or /api/campaigns/[id]/run -> Meta Graph API
  └─ Inbound: Meta POST /api/webhooks/whatsapp (HMAC-SHA256 checked)
              -> privileged Supabase client -> contact, conversation, message
              -> optional keyword auto-reply (within customer service window)
```

### Features implemented

| Feature | Availability |
| --- | --- |
| Owner sign-in | Real Supabase email/password auth |
| Metrics and recent conversations | Real Supabase queries |
| Inbox with inbound messages and send replies | Real Meta API, only inside customer service window; outbound shows `accepted` until a delivery webhook |
| Contacts and consent tracking | Add, search, block/unblock |
| Campaigns | Approved templates **without variables**, opted-in and unblocked contacts only, manually process ≤10 per request |
| Auto-replies | First keyword match, cooldown, only on new inbound text |
| Settings | Graph API reachability, WABA subscriptions count, messages recorded, copy webhook URL |
| Data security | HMAC-verified POST, RLS, owner check, no exposed secret keys |
| Multi-agent assignment | **Not implemented** |
| Attachments/media upload | **Not implemented** (inbound non-text shows placeholder) |
| Meta embedded signup, template authoring | **Not implemented** — use Meta Manager |
| Automatic queue + retries, per-recipient campaign status UI | **Not implemented** — database stores delivery outcomes |
| End-to-end production integration test | **Not run**, credentials not provided |

## 1. Setup requirements

- Node.js **22+** and npm.
- **New Supabase project** (do not run schema blindly on your existing CRM database).
- Meta Developer App with WhatsApp use case and owned WhatsApp Business Account (WABA).
- A WhatsApp phone number registered for Cloud API, permanent system-user token with appropriate messaging/management permissions, App Secret, Phone Number ID, WABA ID.
- Stable public HTTPS callback URL for Meta (e.g. a Vercel deployment). For local development, use ngrok or similar with forwarding to `http://localhost:3000`.

## 2. Create database and owner account

1. Create a new project at https://supabase.com/dashboard.
2. Open **SQL Editor** → New query → paste the entire [`sql/schema.sql`](sql/schema.sql) → **Run**. All 8 tables have RLS. Check Supabase Database → Tables afterwards.
3. In Supabase → **Authentication → Users**, create your own login user (email/password), or enable the desired supported email/password onboarding. This CRM intentionally does not have public signups.
4. Copy the user's **UUID** (not their email). Put it in `CRM_OWNER_USER_ID`. Only this UUID is allowed to call CRM endpoints.
5. In Supabase Project Settings / API keys, obtain URL, publishable key, and service-role secret (or current server-side secret). **Do not expose the secret client-side.**
6. If you have disabled the Supabase Data API or changed exposed schemas, enable `public` for authenticated requests. The schema grants authenticated privileges and enforces RLS.

Workspace creation is automatic on the first successful owner login using `POST /api/bootstrap`. Contact creation includes a database trigger that atomically creates the matching conversation. Do **not** use a privileged public signup trigger.

## 3. Configure and run locally

```powershell
# In Windows PowerShell, inside the extracted folder:
cd whatsapp-crm-pro
copy .env.example .env.local
npm install
npm run dev
```

Open **http://localhost:3000**, sign in with your Supabase owner account. Fill *all* `.env.local` values **before** running. Restart after editing environment variables.

**Never publish `.env.local` or paste your token/PIN into GitHub or screenshots.** `.env.local` is gitignored.

### Mandatory environment variables

| Key | Description |
| --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` | New Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Public client key; not service-role |
| `SUPABASE_SERVICE_ROLE_KEY` | Server-only Supabase service-role/secret key |
| `CRM_OWNER_USER_ID` | Allowed Supabase Auth user UUID |
| `META_ACCESS_TOKEN` | Server-only Meta permanent System User access token |
| `META_PHONE_NUMBER_ID` | Sender phone number ID, **not the phone digits** |
| `META_WABA_ID` | WhatsApp Business Account ID |
| `META_APP_SECRET` | Meta App secret for webhook HMAC verification |
| `META_WEBHOOK_VERIFY_TOKEN` | Your own random string, identical to Meta webhook verify token |
| `META_GRAPH_VERSION` | Meta Graph version (starter defaults to `v27.0`; use a version supported by your app) |
| `NEXT_PUBLIC_APP_URL` | Public app URL for convenience |

If your Supabase instance uses the legacy anon key instead of a publishable key, set that value in `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`; it is a public key and **does not** replace RLS.

## 4. Connect Meta WhatsApp Cloud API

1. Go to https://developers.facebook.com/apps/ → your App → WhatsApp use case → **Production Setup**.
2. Check that phone number status is truly **Connected/registered** in https://business.facebook.com/wa/manage/. A green setup checklist or valid token **does not by itself establish phone registration**. If registration is needed, follow Meta's official registration flow and use a two-step PIN within Meta or your own secure server workflow; **this CRM does not store a PIN**.
3. Start your app with `npm run dev` and a public tunnel. Example:

   ```bash
   ngrok http 3000
   ```

4. In Meta **Webhooks** → Configure Callback URL, use:

   `https://YOUR_PUBLIC_DOMAIN/api/webhooks/whatsapp`

   In **Verify token**, enter exactly the value of `META_WEBHOOK_VERIFY_TOKEN`. Select **Verify and save**.
5. In Webhook Fields, toggle **`messages` → Subscribed**. Extra event subscriptions are optional.
6. Make sure your WABA is subscribed to the Meta app (see `/api/connection` Settings results). For real inbound customer webhooks, your Meta app must be in an appropriate published/live state; unpublished apps may only deliver dashboard test webhooks.
7. Send a WhatsApp message from a permitted test number to the registered API number. Use **Inbox** to check it appears.

> **Local Meta test tool:** Meta's `Test` button can send a generic payload that may not map to your real `META_PHONE_NUMBER_ID`, and it may not be a customer message. Our webhook intentionally ignores messages for other phone IDs. Look at `ngrok` requests and Next.js server logs. For a local-only signed end-to-end test, you can run the script below. It posts a synthetic event and will create a synthetic contact/message when your server+database are configured; it does NOT prove a live Meta delivery:

```bash
TEST_CUSTOMER_WA_ID=919999999999 node --env-file=.env.local scripts/test-webhook.mjs
```

On Windows PowerShell:

```powershell
$env:TEST_CUSTOMER_WA_ID="919999999999"
node --env-file=.env.local scripts/test-webhook.mjs
```

Choose a phone number you control for the test, and avoid matching it to enabled auto-reply keyword rules.

**Local verify challenge check**:

```
GET /api/webhooks/whatsapp?hub.mode=subscribe&hub.verify_token=YOUR_VERIFY_TOKEN&hub.challenge=12345
=> 200, body 12345
```

Webhook POST uses **`X-Hub-Signature-256: sha256=...`**, HMAC-SHA256 of raw request body and `META_APP_SECRET`. Unsigned/invalid requests receive 403. For a working Meta test, non-200 responses indicate delivery/processing failure, not an excuse to disable signature validation.

## 5. Business rules and WhatsApp limitations

- **Delivery status:** Meta API acceptance is recorded as `accepted`, **not** as proof of delivery. Signed status webhooks update messages and campaign-delivery rows to `sent`, `delivered`, `read`, or `failed` when Meta sends those events.
- **Text replies:** permitted only inside Meta's customer service window after a real inbound message. The UI and `/api/messages` enforce a conservative **23-hour** cutoff to avoid edge timing issues; use an approved template when it is closed.
- **Marketing campaigns:** send only to contacts marked as expressly opted in; the add-contact UI records a manual consent attestation. This does not replace independent, auditable evidence of consent if your compliance needs require it.
- Campaign template names/language must already be **approved by Meta**, and the current implementation supports templates **without variable components**.
- Campaign sending runs in manual batches of 10, with a database-level query for remaining eligible contacts (no fixed 1,000-contact ceiling) and a DB reservation for each contact before requesting Meta. This is to reduce duplicate sends; it is **not** a full reliable queue. Review `campaign_deliveries` to troubleshoot failures. A failed or interrupted claim will need an explicit operator review; the UI doesn't retry claims automatically.
- An inbound exact keyword `STOP`, `UNSUBSCRIBE`, or `OPT OUT` automatically revokes promotional opt-in and attempts an acknowledgment; this does not substitute for a full documented preference/consent-management policy.
- Customer messages and most Meta Cloud API costs are governed by Meta's current pricing and messaging policies. Marketing templates may have charges. App hosting and database service plans can also incur costs. This repository itself is free source code.
- Do not treat the optional `subscribedApps` count as evidence that your phone is registered or your app is published.
- On WhatsApp Business App + API coexistence, only rely on a migration/coexistence flow explicitly supported by Meta for your setup. Avoid registering/unregistering a production number casually.

## 6. Deploy to Vercel

1. Push this source to a **private GitHub repository**, **without** `.env.local`.
2. Import it at https://vercel.com/new. Framework auto-detect: Next.js. Check licensing/plan conditions for commercial use.
3. Add all environment variables in Vercel → Project → Settings → Environment Variables.
4. Deploy and open the public HTTPS URL, verify `/api/health` returns JSON.
5. Change your Meta Webhook callback URL to `https://YOUR_VERCEL_DOMAIN/api/webhooks/whatsapp` (keep Verify Token unchanged), click Verify and Save, and ensure `messages` is subscribed.
6. Verify Meta signature checks, actual inbound customer messages, delivery-status updates, manual reply, and campaign template sending. Set up logs/monitoring and database backup policy before real customers.

## 7. Test and limits

```bash
npm run test       # offline Node test: signature and schema presence
npm run typecheck  # after npm install
npm run build      # after npm install
```

This reviewed repository passed 13 local unit/static tests and 34 TypeScript/TSX files parsed without syntax errors, but dependency-based compilation/build and live end-to-end integration were not run. **No live Supabase database migration, Meta request, browser E2E, or Vercel deployment has been performed in this environment.** See actual verification results in the delivery message.

### Security, reliability, and roadmap

- **Single owner** only. For multiple staff, design a secure `workspace_members` authorization layer first rather than granting all users access to the same secret.
- Use a queue for large campaign sends and inbound processing; Vercel API routes are not a replacement for durable jobs.
- Add durable audit logs, opt-in evidence/opt-out keyword handling, retention policies, data export/delete, rate limiting, protection against concurrent automation races, observability and alerting.
- Consider template variables, interactive messages, attachments/media processing, multi-agent assignment, and detailed campaign delivery UI in a subsequent version.
- Improve concurrency on conversation unread counters (e.g. database RPC), and persist idempotent webhook events before longer processing for high-volume workloads.
- Account/phone credentials are **environment variables**, never stored in a database row or frontend. Use cloud secret management and rotation for production.
- For privacy-sensitive data, review WhatsApp Platform rules, customer-consent requirements, and applicable Indian data-protection law.

## Folder structure

```
src/app/(dashboard)/*               dashboard, inbox, contacts, campaigns, automations, settings
src/app/api/*                       protected Next.js API routes
src/app/api/webhooks/whatsapp       Meta challenge + signed event processing
src/components                     shared UI and sidebar
src/lib                            authentication, session-refresh Proxy, Meta API, helpers
src/proxy.ts                       Next.js 16 session-refresh entrypoint
sql/schema.sql                     8-table SQL schema, indexes and RLS
scripts/test-webhook.mjs           optional local signed payload test
tests/*.test.mjs                  offline HMAC, Meta HTTP mock and static integrity tests
AUDIT_REPORT.md                    exact review results and live QA checklist
.env.example                       safe environment template
```

## Troubleshooting

| Symptom | Likely cause / next check |
| --- | --- |
| Owner cannot sign in | Supabase Auth user/password/confirmed email, URL and publishable key |
| Setup needs attention | Run SQL schema on NEW DB, verify `CRM_OWNER_USER_ID`, inspect server logs |
| "Graph API not reachable" | Token, permissions, Phone Number ID, version or Meta access |
| Meta test says success, inbox blank | Payload may not contain your phone ID, or is a non-message event; inspect ngrok + logs |
| Webhook GET 403 | Verify token mismatch |
| Webhook POST 403 | App secret or signature mismatch; don't disable verification |
| Webhook POST 500 | Server/DATABASE/config errors; inspect console |
| Inbound never arrives | App unpublished, wrong callback, unsubscribed `messages`, WABA subscription, tunnel offline |
| Message send 422 | No inbound message within the last ~23 hours; use approved template |
| Meta send error | Approved template, phone registration, Meta permissions, customer eligibility |

Official references:
- https://developers.facebook.com/docs/whatsapp/cloud-api
- https://www.postman.com/meta/whatsapp-business-platform/documentation/wlk6lh4/whatsapp-cloud-api
- https://supabase.com/docs/guides/auth/server-side/nextjs
- https://supabase.com/docs/guides/database/postgres/row-level-security
