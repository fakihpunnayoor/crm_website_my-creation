# Pulse CRM — AI Agents feature (adapted from uploaded WACRM)

This ZIP is the **previously supplied Pulse WhatsApp CRM** with a single AI assistant added. It adapts the user-supplied WACRM AI Agent feature to Pulse's workspace/message/database structure. It does **not** replace the app with WACRM. The supplied WACRM is MIT-licensed; original license text is included as `AI_SOURCE_LICENSE.txt`. Original functions reused/adapted: `types`, `defaults`, `chunkText`, `latestUserMessage`, provider adapters, generation and auto-reply patterns. Pulse-specific settings, database, endpoints, UI and webhook integration were written for Pulse.

## 1. Back up your running project

Stop `npm run dev`. Extract this ZIP to a **new folder** (or create a branch). **Never overwrite** your real `.env.local` with an example file. This ZIP deliberately includes **no** `.env.local`, customer data, WACRM `.git`, `node_modules`, or `.next` build cache. Move **your existing private `.env.local` locally** into the new extracted Pulse folder, keeping it off GitHub and outside chats.

## 2. Add AI tables to your existing Supabase project

Use the **same Supabase project** that Pulse CRM already uses, where your existing Inbox and messages are stored.

1. Supabase → SQL Editor → New query.
2. Open `sql/ai-agent-migration.sql` from this ZIP. Read it and run it **once**.
3. It adds `ai_configs`, `ai_knowledge_documents`, `ai_usage_log`, `ai_reply_attempts`, and AI fields on `conversations`. Existing contacts/messages are preserved. RLS stays enabled. No secrets are stored in the database.
4. **Do not re-run `sql/schema.sql` on the existing CRM database.** That is for fresh projects only.

The migration uses an atomic `claim_ai_reply_slot(...)` SQL function for per-message deduplication, rate gating, and per-conversation cap. No `SECURITY DEFINER` was added.

## 3. Add the provider key securely

In the **same folder as `package.json`**, update your local `.env.local`:

```env
# Add to your existing Supabase and Meta settings:
AI_API_KEY=YOUR_PROVIDER_API_KEY
AI_PROVIDER=openai
AI_MODEL=gpt-4o-mini
AI_REQUEST_TIMEOUT_MS=12000
AI_CONTEXT_MESSAGE_LIMIT=20
```

- Create an API key with your chosen AI provider. **ChatGPT Plus does not include OpenAI API usage**; API calls are billed separately.
- Provider options on `/agents`: OpenAI, Anthropic, OpenAI-compatible.
- If using an OpenAI-compatible API, add `AI_BASE_URL=https://YOUR_PROVIDER_API_BASE/v1` (an operator-controlled HTTPS URL), then select that provider in AI Agent Settings. Private/local URL hosts are blocked.
- **Do not** add `NEXT_PUBLIC_` to AI_API_KEY, Meta access tokens, or Supabase service-role keys. Do not paste them into chat, screenshots or GitHub.
- The source WACRM's credentials were **not** copied.

## 4. Install and test

In the project folder:

```powershell
npm install
npm run typecheck
npm test
npm run dev
```

Open `http://localhost:3000/agents`. The new sidebar item is **AI Agents**.

1. **Setup:** choose provider/model; fill **Business system prompt**, e.g. a customer-support personality and rules. Save it with AI turned **off** initially.
2. **Knowledge:** add actual product catalog data, pricing, returns/shipping policies, FAQ documents; the engine retrieves up to 4 relevant text chunks per question (lexical retrieval; not embeddings).
3. **Playground:** test a sample customer message; it **does not** send WhatsApp messages.
4. **Setup:** switch **Enable AI Agent** ON, then **Automatically reply** ON, and save.
5. **Inbox:** use **Pause AI / Resume AI** per conversation, or **Draft with AI** to suggest but not send a reply.
6. **Usage:** review recent model-call counts and token usage (not provider invoice amounts).

## 5. WhatsApp webhooks

Keep your existing **Meta callback URL**, verify token, subscription and phone-number IDs **unchanged**, e.g.:

`https://YOUR-LIVE-HTTPS-DOMAIN/api/webhooks/whatsapp`

- `POST /api/webhooks/whatsapp` verifies Meta's HMAC SHA-256 signature **before** processing.
- Incoming WhatsApp text is committed to Supabase first; only a **new** message can trigger an AI reply.
- An explicitly matching **keyword automation** wins over AI. If STOP/UNSUBSCRIBE/OPT OUT is sent, marketing opt-out handling takes precedence and AI is not invoked.
- AI runs in Next.js `after()` callback so Meta receives HTTP 200 without waiting for the provider. This is best-effort: a crashed process or exhausted serverless duration can still prevent auto-reply. For higher volume, add a persistent job queue/worker and retry states before production launch.
- Auto reply is limited by a per-conversation cap (default 5; editable) and 20-second minimum spacing. The model is instructed to request **human handoff** rather than invent business details.
- `ai_reply_attempts` ensures an inbound event cannot generate a second outbound reply after it has claimed its send slot. If a send fails the slot remains consumed as a conservative duplicate-prevention choice; inspect server logs.
- Only verified, inbound, **text** messages trigger AI; no media transcription/vision has been imported.
- Outside the 24-hour customer service window, use Meta-approved WhatsApp templates instead of unsolicited freeform text.

## 6. Production cautions

**Not certified as production-ready.** Requires successful local `npm install`, `npm run build`, a live AI provider key, real Meta callbacks, webhook signature handling, Supabase migrations, cost/usage monitoring, privacy/legal review, explicit human fallback, and load testing. This environment could run the pure Node tests, but could **not** fetch npm packages or execute live provider/webhook integration tests.

No existing live Supabase schema was changed by producing this ZIP. You must choose when to run the additive migration.

## File map

- `src/lib/ai/`: AI prompt, provider adapters, knowledge, generation, dispatch
- `src/app/(dashboard)/agents/page.tsx`: Setup, Playground, Knowledge, Usage
- `src/app/api/ai/{config,playground,knowledge,draft,usage,conversation}/route.ts`: authenticated APIs
- `src/app/api/webhooks/whatsapp/route.ts`: AI hook after verified inbound text (keyword rules first)
- `src/app/(dashboard)/inbox/page.tsx`: Pause/Resume & Draft with AI
- `sql/ai-agent-migration.sql`: additive migration for existing Pulse CRM
- `tests/ai-agent.test.mjs`: new unit/static checks

Original uploaded WACRM has much deeper features (encrypted per-account BYO keys, vector embeddings, full multi-agent routing, broad workflow builder). Those are **not** transferred; this integration is a single-agent MVP with server-side provider key, lexical knowledge, per-chat controls, and safe auto-replies.
