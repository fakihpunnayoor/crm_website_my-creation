-- Pulse CRM AI Agent add-on. Run ONCE on the EXISTING Pulse CRM Supabase project.
-- Do NOT run the entire sql/schema.sql again on an existing DB.
-- No AI credentials stored in the database; configure AI_API_KEY in .env.local / Vercel secrets.

alter table public.conversations
  add column if not exists ai_paused boolean not null default false,
  add column if not exists ai_reply_count integer not null default 0,
  add column if not exists ai_handoff_summary text,
  add column if not exists ai_last_reply_at timestamptz;

create table if not exists public.ai_configs (
  workspace_id uuid primary key references public.workspaces(id) on delete cascade,
  provider text not null default 'openai' check (provider in ('openai','anthropic','openai_compatible')),
  model text not null default 'gpt-4o-mini',
  system_prompt text not null default '',
  is_active boolean not null default false,
  auto_reply_enabled boolean not null default false,
  auto_reply_max_per_conversation integer not null default 5 check(auto_reply_max_per_conversation between 1 and 50),
  updated_at timestamptz not null default now()
);
create table if not exists public.ai_knowledge_documents (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  title text not null check(length(title) between 1 and 150),
  content text not null check(length(content) between 1 and 20000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists ai_kb_by_workspace on public.ai_knowledge_documents(workspace_id,created_at desc);
create table if not exists public.ai_reply_attempts (
  inbound_message_id uuid primary key references public.messages(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  result text not null default 'claimed' check(result in ('claimed','sent','handoff','failed','skipped')),
  error_text text,
  created_at timestamptz not null default now()
);
create table if not exists public.ai_usage_log (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  conversation_id uuid references public.conversations(id) on delete set null,
  mode text not null check(mode in ('auto_reply','playground','draft')),
  provider text not null,
  model text not null,
  prompt_tokens integer not null default 0,
  completion_tokens integer not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists ai_usage_recent on public.ai_usage_log(workspace_id,created_at desc);

alter table public.ai_configs enable row level security;
alter table public.ai_knowledge_documents enable row level security;
alter table public.ai_reply_attempts enable row level security;
alter table public.ai_usage_log enable row level security;

create policy "own_ai_configs" on public.ai_configs for all to authenticated
 using(workspace_id in (select id from public.workspaces where owner_id = (select auth.uid())))
 with check(workspace_id in (select id from public.workspaces where owner_id = (select auth.uid())));
create policy "own_ai_knowledge" on public.ai_knowledge_documents for all to authenticated
 using(workspace_id in (select id from public.workspaces where owner_id = (select auth.uid())))
 with check(workspace_id in (select id from public.workspaces where owner_id = (select auth.uid())));
create policy "own_ai_attempts" on public.ai_reply_attempts for select to authenticated
 using(workspace_id in (select id from public.workspaces where owner_id = (select auth.uid())));
create policy "own_ai_usage" on public.ai_usage_log for select to authenticated
 using(workspace_id in (select id from public.workspaces where owner_id = (select auth.uid())));

grant usage on schema public to authenticated,service_role;
grant select,insert,update,delete on public.ai_configs,public.ai_knowledge_documents to authenticated;
grant select on public.ai_reply_attempts,public.ai_usage_log to authenticated;
grant select,insert,update,delete on public.ai_configs,public.ai_knowledge_documents,public.ai_reply_attempts,public.ai_usage_log to service_role;
grant select,update on public.conversations to service_role;
grant select on public.messages to service_role;
revoke all on public.ai_configs,public.ai_knowledge_documents,public.ai_reply_attempts,public.ai_usage_log from anon;

-- One atomic cap+dedup+cooldown claim per incoming message. SECURITY INVOKER is intentional.
-- Only called from a verified webhook using a server-side service-role client.
create or replace function public.claim_ai_reply_slot(inbound_id uuid, max_replies integer)
returns boolean language plpgsql security invoker set search_path = '' as $$
declare msg record;
begin
  select workspace_id,conversation_id into msg
  from public.messages where id=inbound_id and direction='inbound' and kind='text';
  if not found or max_replies < 1 or max_replies > 50 then return false; end if;
  insert into public.ai_reply_attempts(inbound_message_id,workspace_id,conversation_id)
  values(inbound_id,msg.workspace_id,msg.conversation_id)
  on conflict (inbound_message_id) do nothing;
  if not found then return false; end if;
  update public.conversations set
    ai_reply_count=ai_reply_count+1,
    ai_last_reply_at=now()
  where id=msg.conversation_id and workspace_id=msg.workspace_id
    and not ai_paused and ai_reply_count < max_replies
    and (ai_last_reply_at is null or ai_last_reply_at < now()-interval '20 seconds');
  if not found then
    delete from public.ai_reply_attempts where inbound_message_id=inbound_id;
    return false;
  end if;
  return true;
end;
$$;
revoke all on function public.claim_ai_reply_slot(uuid,integer) from public,anon,authenticated;
grant execute on function public.claim_ai_reply_slot(uuid,integer) to service_role;
