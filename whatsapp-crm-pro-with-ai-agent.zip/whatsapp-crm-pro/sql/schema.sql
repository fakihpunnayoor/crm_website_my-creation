-- Run ONLY on a fresh, dedicated Supabase project. PostgreSQL 15+.
-- All user-facing tables use Row Level Security. No public/anon write access.
create extension if not exists pgcrypto;

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references auth.users(id) on delete cascade,
  name text not null default 'My WhatsApp Workspace',
  created_at timestamptz not null default now()
);
create table if not exists public.contacts (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  phone_e164 text not null check(phone_e164 ~ '^[1-9][0-9]{7,14}$'),
  name text not null default '',
  opted_in boolean not null default false,
  opted_in_at timestamptz,
  blocked boolean not null default false,
  tags text[] not null default '{}',
  created_at timestamptz not null default now(),
  unique(workspace_id,phone_e164), unique(id,workspace_id)
);
create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  contact_id uuid not null,
  last_message_at timestamptz,
  last_preview text,
  unread_count integer not null default 0 check(unread_count>=0),
  status text not null default 'open' check(status in ('open','closed')),
  created_at timestamptz not null default now(),
  unique(workspace_id,contact_id), unique(id,workspace_id),
  foreign key(contact_id,workspace_id) references public.contacts(id,workspace_id) on delete cascade
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  conversation_id uuid not null,
  contact_id uuid not null,
  external_id text unique,
  direction text not null check(direction in ('inbound','outbound')),
  kind text not null default 'text',
  body text not null default '',
  status text not null default 'received',
  error_text text,
  created_at timestamptz not null default now(),
  foreign key(conversation_id,workspace_id) references public.conversations(id,workspace_id) on delete cascade,
  foreign key(contact_id,workspace_id) references public.contacts(id,workspace_id) on delete cascade
);
create table if not exists public.campaigns (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  name text not null,
  template_name text not null,
  template_language text not null default 'en_US',
  status text not null default 'draft' check(status in ('draft','running','completed')),
  created_at timestamptz not null default now(),
  unique(id,workspace_id)
);
create table if not exists public.campaign_deliveries (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  campaign_id uuid not null,
  contact_id uuid not null,
  external_id text,
  status text not null default 'pending' check(status in ('pending','accepted','sent','delivered','read','failed')),
  error_text text,
  created_at timestamptz not null default now(),
  unique(campaign_id,contact_id),
  foreign key(campaign_id,workspace_id) references public.campaigns(id,workspace_id) on delete cascade,
  foreign key(contact_id,workspace_id) references public.contacts(id,workspace_id) on delete cascade
);
create table if not exists public.automation_rules (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  name text not null,
  keyword text not null,
  reply_text text not null,
  enabled boolean not null default true,
  cooldown_minutes integer not null default 60 check(cooldown_minutes between 1 and 10080),
  created_at timestamptz not null default now(),
  unique(id,workspace_id)
);
create table if not exists public.automation_runs (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  rule_id uuid not null,
  contact_id uuid not null,
  sent_at timestamptz not null default now(),
  foreign key(rule_id,workspace_id) references public.automation_rules(id,workspace_id) on delete cascade,
  foreign key(contact_id,workspace_id) references public.contacts(id,workspace_id) on delete cascade
);
create index if not exists idx_contacts_workspace on public.contacts(workspace_id,created_at desc);
create index if not exists idx_conversations_recent on public.conversations(workspace_id,last_message_at desc);
create index if not exists idx_messages_conversation on public.messages(conversation_id,created_at asc);
create index if not exists idx_messages_inbound on public.messages(contact_id,direction,created_at desc);
create index if not exists idx_deliveries_campaign on public.campaign_deliveries(campaign_id,status);
create index if not exists idx_automation_runs_recent on public.automation_runs(rule_id,contact_id,sent_at desc);

alter table public.workspaces enable row level security;
alter table public.contacts enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.campaigns enable row level security;
alter table public.campaign_deliveries enable row level security;
alter table public.automation_rules enable row level security;
alter table public.automation_runs enable row level security;

create policy "workspace_owner" on public.workspaces for all to authenticated
  using(owner_id=(select auth.uid())) with check(owner_id=(select auth.uid()));
create policy "own_contacts" on public.contacts for all to authenticated
  using(workspace_id in (select id from public.workspaces where owner_id=(select auth.uid())))
  with check(workspace_id in (select id from public.workspaces where owner_id=(select auth.uid())));
create policy "own_conversations" on public.conversations for all to authenticated
  using(workspace_id in (select id from public.workspaces where owner_id=(select auth.uid())))
  with check(workspace_id in (select id from public.workspaces where owner_id=(select auth.uid())));
create policy "own_messages" on public.messages for select to authenticated
  using(workspace_id in (select id from public.workspaces where owner_id=(select auth.uid())));
-- Messages are created by verified inbound webhooks or authenticated server API only (service role).
create policy "own_campaigns" on public.campaigns for all to authenticated
  using(workspace_id in (select id from public.workspaces where owner_id=(select auth.uid())))
  with check(workspace_id in (select id from public.workspaces where owner_id=(select auth.uid())));
create policy "own_deliveries" on public.campaign_deliveries for select to authenticated
  using(workspace_id in (select id from public.workspaces where owner_id=(select auth.uid())));
create policy "own_automation_rules" on public.automation_rules for all to authenticated
  using(workspace_id in (select id from public.workspaces where owner_id=(select auth.uid())))
  with check(workspace_id in (select id from public.workspaces where owner_id=(select auth.uid())));
create policy "own_automation_runs" on public.automation_runs for select to authenticated
  using(workspace_id in (select id from public.workspaces where owner_id=(select auth.uid())));

-- REST API privileges are distinct from RLS; grant only authenticated and only the needed operations.
grant usage on schema public to authenticated;
grant select,insert,update,delete on public.workspaces,public.contacts,public.conversations,public.campaigns,public.automation_rules to authenticated;
grant select on public.messages,public.campaign_deliveries,public.automation_runs to authenticated;
revoke all on public.workspaces,public.contacts,public.conversations,public.messages,public.campaigns,public.campaign_deliveries,public.automation_rules,public.automation_runs from anon;


-- Automatically create a conversation with every contact, in the SAME transaction.
-- Prevents a partially-created contact if the conversation insert fails.
create or replace function public.new_contact_conversation()
returns trigger language plpgsql security invoker set search_path = '' as $$
begin
  insert into public.conversations(workspace_id,contact_id)
  values(new.workspace_id,new.id)
  on conflict (workspace_id,contact_id) do nothing;
  return new;
end;
$$;
drop trigger if exists contact_conversation_on_insert on public.contacts;
create trigger contact_conversation_on_insert
  after insert on public.contacts
  for each row execute function public.new_contact_conversation();

-- Return only unclaimed campaign recipients; works beyond Supabase's default
-- 1,000-row Data API response limit without downloading the whole contact list.
-- Invoked by the server service role after owner and workspace checks.
create or replace function public.next_campaign_targets(campaign_uuid uuid, requested_count integer default 11)
returns table(contact_id uuid, phone_e164 text)
language sql security invoker set search_path = '' as $$
  select c.id,c.phone_e164
  from public.contacts c
  join public.campaigns camp on camp.workspace_id=c.workspace_id
  where camp.id=campaign_uuid
    and c.opted_in=true and c.blocked=false
    and not exists(
      select 1 from public.campaign_deliveries d
      where d.campaign_id=camp.id and d.contact_id=c.id
    )
  order by c.created_at,c.id
  limit least(greatest(requested_count,1),100);
$$;
revoke all on function public.next_campaign_targets(uuid,integer) from public, anon, authenticated;
grant execute on function public.next_campaign_targets(uuid,integer) to service_role;

-- Explicit privileges are required even for service_role. RLS remains enabled.
grant select,insert,update,delete on public.workspaces,public.contacts,public.conversations,public.messages,public.campaigns,public.campaign_deliveries,public.automation_rules,public.automation_runs to service_role;
